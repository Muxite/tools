---
id: nuwa-speaker-script
status: planned-unrehearsed
source: output/Nuwa Talk rev3.pptx
last_reviewed: 2026-10-23
next_action: Rehearse the AI4R-centered rev3 aloud
---
# Nuwa rev3 speaker script

Nine main slides, two hidden backups. Planned 6:40, not rehearsed aloud.

## 1. Main slide

TIME 0:25. Nuwa takes a person and turns their documented thinking into an AI skill. You name someone, Nuwa researches what they wrote, said and did, and the result tells an agent how to reason and respond from that perspective. The promise for AI4Research is access to useful ways of thinking on demand. This talk asks where that adds value, where the approximation fails, and what we should test first.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md

## 2. Main slide

TIME 0:45. The skill has five layers. Mental models capture how the person frames a problem. Decision heuristics capture their quick rules for making judgments. Expression DNA gives the answer their characteristic voice. Values, anti-patterns and contradictions preserve priorities and tensions, rather than smoothing the person into generic advice. Honest limits state what the reconstruction cannot know. The result can therefore do more than repeat quotations: it can apply a documented pattern to a question the person never answered. That last step is an inference. It must remain distinguishable from the person's actual public position. Public statements, incomplete records, and a date cutoff constrain the result.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/extraction-framework.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md

## 3. Main slide

TIME 0:50. Nuwa starts with a named person and a scope. Its six research streams look at writings, long conversations, short-form expression, outside criticism, actual decisions, and the timeline. The decisions and criticism matter because stated beliefs may differ from behavior. The agent saves this research, then extracts three to seven mental models, five to ten heuristics, and the person's expression patterns. It checks whether a model recurs across domains, supports reasoning on new cases, and distinguishes this person. It writes a skill with sources and boundaries, then tests known positions, an unfamiliar question, and recognizable style. The work can be expensive, so the instructions also support reduced research and serial execution. The deliverable is a skill directory, with supporting research.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/extraction-framework.md

## 4. Main slide

TIME 0:45. Take the Karpathy perspective included in the repository. Its documented lenses include the gap between a demo and reliable deployment, difficult tail cases, and learning from real implementations. Suppose an AI4Research agent sees a paper claiming a highly reliable research assistant. A procedure derived from those lenses would ask which task distribution the benchmark covers, what happens in a long run when tools fail, and which evidence can be reproduced. This shows how a model becomes research questions. The response is our illustration derived from the skill, not a quotation or a claim about Karpathy's view of a particular paper. These questions may also arise from a generic checklist. Added value over a generic reviewer is untested, which is why that comparator belongs in the trial.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/examples/andrej-karpathy-perspective/SKILL.md

## 5. Main slide

TIME 0:55. AI4Research is the point of studying Nuwa. The reusable lesson is how to turn documented reasoning into a procedure an agent can apply. Nuwa gathers primary material, decisions and criticism; extracts explicit models with failure conditions; and derives concrete research questions from them. We can imitate that method in hypothesis generation, experiment design and evaluation. The result could retain a named perspective or become a neutral research procedure with its intellectual sources visible. Hypothesis work should preserve competing explanations. Experiment design should turn assumptions into evidence questions. Evaluation should retain counterexamples rather than write a persuasive consensus. These are proposed improvements to how AI4R authors and uses reasoning capabilities. Their task benefit still needs measurement; importing a famous voice alone would not establish it.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/extraction-framework.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md
LOCAL CONTEXT
Designs/CC Reference.md; Designs/skills-to-cc-mapping.md. Proposed capability improvement, not implemented support or a measured gain.

## 6. Main slide

TIME 0:50. There are four lessons to carry into AI4Research. A public record is incomplete, so we should keep claim-level sources and label inference. A distinctive voice can create authority, so scientific outputs should use evidence rather than a person's name as support. Familiar public-position tests measure a narrow kind of fidelity, so we need new research tasks and independent scoring. Finally, the quality checker counts structure and keywords: our saved empty-content probe passed all six functions, including missing sources. AI4R should fail checks when required evidence is missing and use semantic assessment separately from lint. Separate judging agents still need protection against shared-model biases. Nuwa itself acknowledges many limitations; the issue is whether its checks enforce them in the output.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/fidelity-scorecard.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/scripts/quality_check.py
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/examples/elon-musk-perspective/FIDELITY.md

## 7. Main slide

TIME 0:50. This is the additional link to the CC factory. We could make a bounded Nuwa-like authoring capability that consumes a prepared expert corpus and a target research responsibility. It would extract source-linked reasoning rules, contradictions and failure conditions, then draft a reviewer CC with typed inputs and outputs. That is a proposed reasoning-skill branch within the broader factory, with a different transformation from tool wrapping. Authoring stages, evidence resources and generated product CCs have separate versions. The product still needs independent source checks, held-out task evaluation and ordinary admission. A flat pipeline should come first; a composite authoring CC can follow only if repeated value justifies it. Source preparation remains separately authorized, and the existing offline Builder should consume prepared inputs. Start with one expert-derived review procedure rather than automate every part of Nuwa.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/extraction-framework.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md
LOCAL CONTEXT
Designs/Capability Capsule Factory Feature.md; Designs/Per Lab Capability Factory Design.md; Designs/skills-to-cc-mapping.md. Proposed M2 branch, not implemented or admitted.

## 8. Main slide

TIME 0:50. Start with one source-rich expert corpus and one bounded responsibility, such as reviewing an agent benchmark. Use Nuwa's extraction method to draft a neutral, source-linked review procedure. Pin the procedure and cutoff, and require outputs to distinguish source-supported rules, framework inference and current task evidence. Compare it against a plain reviewer and a length-matched generic review checklist. All arms get the same expert-source excerpts and task evidence, model, tools and runtime budget. Freeze new tasks and scoring before generation, and use blinded human judgment. Measure supported useful objections, missed failures, calibration and cost. Record authoring cost separately. Retain the procedure only if it improves real review behavior beyond the generic checklist. A persona-voice ablation can follow later if relevant.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/fidelity-scorecard.md
LOCAL CONTEXT
Designs/skills-to-cc-mapping.md; separate proposal, not a revision to the maintained accuracy study.

## 9. Main slide

TIME 0:30. Nuwa shows how documented human reasoning can become a reusable skill. For AI4Research, we should learn the evidence-to-procedure method: preserve sources and disagreement, extract usable rules, and derive concrete investigation steps. A Nuwa-like authoring pipeline could become a reasoning-skill branch of the CC factory. We should improve its assurance with explicit source checks, independent unseen tasks and bounded cost. The next decision is whether one such reviewer improves real AI4R work beyond an equally informed agent. That experiment earns further integration; resemblance to a person does not.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md
LOCAL CONTEXT
Designs/skills-to-cc-mapping.md; Designs/Capability Capsule Factory Feature.md

## 10. Hidden backup

BACKUP. All arms receive the same frozen expert-source excerpts and task evidence. The plain reviewer gets no added procedure. The generic arm gets a length-matched general review checklist. The extracted-method arm gets neutral rules and limits produced through the Nuwa-inspired process. Hold the model, tools, permissions and runtime budgets fixed, freeze unseen tasks and scoring before generation, and blind human assessment. Judge supported useful objections, missed failure modes, unsupported claims, uncertainty, latency and cost. Record corpus preparation and authoring effort separately from runtime cost. This identifies the increment beyond a generic checklist, not the causal effect of each Nuwa phase. A later voice ablation can test whether persona framing helps or hurts. No experimental result is claimed.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/fidelity-scorecard.md
LOCAL CONTEXT
Designs/skills-to-cc-mapping.md; Luna adversarial review, 2026-10-23.

## 11. Hidden backup

BACKUP. A skill is an instruction bundle, not a capsule declaration or runtime permission. For governed use, bind a pinned skill body and evidence resources to a selected agent responsibility. Declare typed task and evidence inputs, a structured critique output, tool needs, effects, budgets and failure behavior. Changes to the worker body require the existing versioning, checks and admission path. The semantic verifier remains declaration-and-output-only; source/input-dependent checks belong in the protected host path. Nuwa's creation workflow can remain an authoring tool while this deployment is tested. Automating that workflow is a later choice, not a prerequisite or the main value proposition.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md
LOCAL CONTEXT
Designs/CC Reference.md; Designs/skills-to-cc-mapping.md

