---
id: nuwa-presentation
status: completed-documentation
source: ../../../Sources/Prompts/2026-10-23-nuwa-person-to-skill-and-orange.txt; ../../../Sources/Prompts/2026-10-23-nuwa-ai4r-methodology-and-luna.txt; references/source-review.md
last_reviewed: 2026-10-23
next_action: Rehearse rev3 aloud; define the frozen expert-source corpus and generic-checklist control before any AI4R trial
---
# Nuwa rev3: what AI4Research can learn

Open [Nuwa Talk rev3.pptx](output/Nuwa%20Talk%20rev3.pptx). **Nine main slides and two hidden backups**, planned **6:40**. The ninth main slide is the requested addition connecting a Nuwa-like pipeline to the CC factory. Speaker notes include the script and pinned sources. Timing remains an estimate, not an aloud rehearsal.

Rev3 uses burnt orange, terracotta and warm cream. The story starts with Nuwa turning a person's documented thinking into a skill. AI4Research is the purpose of the assessment: where the idea and methodology could help, what to imitate, what to improve, and how to test it. The deck does not reuse Paper2Agent's workflow or present persona roleplay as the research objective. Earlier rev2 files remain for history.

## Main story

| Slide | Point | Planned time |
|---|---|---|
| 1 | A person becomes an AI skill, with potential AI4R value | 0:25 |
| 2 | Public evidence becomes models, rules, expression, values and limits | 0:45 |
| 3 | A host agent executes Nuwa's research, extraction, authoring and checks | 0:50 |
| 4 | A Karpathy-derived benchmark-review example illustrates the mechanism | 0:45 |
| 5 | AI4R could reuse extracted procedures in hypotheses, design and evaluation | 0:55 |
| 6 | Nuwa's pitfalls suggest stronger evidence and task checks | 0:50 |
| 7 | A proposed Nuwa-like reasoning-method branch could extend the CC factory | 0:50 |
| 8 | A focused trial tests one expert-derived procedure | 0:50 |
| 9 | Learn the method and earn further integration with task evidence | 0:30 |
| 10 | Hidden backup: plain, generic-checklist and extracted-method arms | |
| 11 | Hidden backup: governed CC binding and checks | |

The proposed branch separates evidence resources, authoring-stage CCs, candidate reviewer CCs, independent qualification and ordinary admission. It is an M2 proposal, not a built pipeline or an admitted capability. A flat workflow comes before any composite. Source preparation keeps its own authority boundary.

## Adversarial review and revision

At the user's request, **gpt-6-luna** adversarially reviewed the draft, pinned source snapshots and AI4R context. The [raw report](../../../Resources/review-batches/2026-10-23-nuwa-orange/luna-adversarial-review.txt) is retained. Its findings led to visible qualifications on value and the example, an explicit host-agent label, a stronger factory diagram, a generic-checklist control, clearer output labels and shorter headings.

The comparison now gives every arm the same frozen expert-source excerpts and task evidence. It compares a plain reviewer, a length-matched generic checklist, and a neutral Nuwa-derived procedure under matched model/tools/runtime budgets. Unseen tasks and scoring freeze first. Authoring cost is separate. This tests incremental task usefulness beyond generic prompting; it does not isolate every extraction phase or establish persona fidelity.

## Files

- [Editable deck](output/Nuwa%20Talk%20rev3.pptx), [speaker script](speaker-script.md), [contact sheet](review-orange/contact-sheet.jpg).
- [Builder](build_pptx.py), [finalizer](finalize.mjs), [PowerPoint render script](render.ps1).
- [Source review](references/source-review.md), [original source receipts](references/source-receipts.json).
- [Final artifact validation](.build-orange/Nuwa%20Talk%20rev3.validation.json).
- Original [checker probe](review/checker-probe.json): a structural finding from 2026-10-22, not a persona-quality experiment.

The GitHub API confirmed on 2026-10-23 that main still points to `7812110bf7e5a2b01b6aa5a738568044121bbfa2`. The primary agent reread the research/extraction/generation/validation instructions, template, rubric and checker. Selected snapshots retain the MIT license. No Nuwa installation, skill generation, AI4R integration, admission or comparative accuracy result is claimed.

All final slides are rendered through PowerPoint and inspected individually. The finalizer checks package integrity, slide geometry, preserved Segoe UI text, editable backup tables and first-party import. Sources and notes remain embedded. The notebook validator separately retains its existing Paper2Agent missing-rev9 link errors; that older project remains unchanged.

To rebuild, run the builder with the bundled Python runtime, finalize to a fresh output revision, then render and inspect that exact file. The finalizer preserves existing outputs. Historical builder/notes snapshots are under `history/rev2/`.
