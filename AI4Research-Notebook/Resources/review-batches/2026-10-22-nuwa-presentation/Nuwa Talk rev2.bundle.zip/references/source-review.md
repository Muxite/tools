---
id: nuwa-source-review
status: reviewed-source-and-proposal
source: https://github.com/alchaincyf/nuwa-skill/tree/7812110bf7e5a2b01b6aa5a738568044121bbfa2; ../../../skills-to-cc-mapping.md; ../../../Capability Capsule Factory Feature.md
last_reviewed: 2026-10-22
next_action: Preserve the distinction between repository fidelity reports and independently measured task value
---
# Nuwa source review and claim ledger

Nuwa is a Markdown/YAML skill workflow, not a trained model or a standalone orchestrator. The main skill guides an agent through source collection, framework synthesis, skill construction, validation and refinement. The helper scripts cover subtitle handling, research summaries and structural checks. Selected files were read from a temporary clone at commit `7812110bf7e5a2b01b6aa5a738568044121bbfa2`; source snapshots and hashes are retained beside this note.

## Claims in the talk

| Slide | Claim | Evidence and scope |
|---|---|---|
| 1–2 | Thinking patterns can be packaged as reusable instructions | Core `SKILL.md` and extraction framework. Reusability is the intended mechanism; improved AI4Research outcomes are unmeasured. |
| 3 | Six research dimensions, 3–7 models and 5–10 heuristics | Core Phases 1–3; these are authoring requirements rather than a mechanically enforced pipeline. |
| 3 | Mental models should recur across domains, support new reasoning and be distinctive | `references/extraction-framework.md`. These filters are qualitative judgments. |
| 4 | Output includes skill instructions, research files and available source material | Core directory contract and `references/skill-template.md`. Helpers and actual corpus contents vary. |
| 4 | Factual questions should trigger tool research | Core generated Agentic Protocol. Not proof of runtime compliance. |
| 4 | No weight training occurs | Inspected artifact structure and workflow; “distillation” is instruction synthesis. |
| 5 | Karpathy example emphasizes deployment reliability, implementation evidence and difficult cases | `examples/andrej-karpathy-perspective/SKILL.md`. The research task, review schema and proposed CC are our illustration. |
| 6 | A Nuwa-derived method could become a bounded agent CC | Our proposed mapping against local skills-to-CC and M2 factory notes. No implementation, admission or gain claimed. |
| 7 | Separate answering and judging agents are prescribed | `references/fidelity-scorecard.md`; this reduces direct self-scoring but does not prove independent errors. |
| 7 | Known-position checks may overlap the skill's evidence | Our analysis of the rubric, which uses repeatedly stated public positions. No measured leakage rate claimed. |
| 7 | A placeholder skill passed 6/6 structural checks | Reproduced 2026-10-22 by `probe_quality_checker.py`; input and booleans in `review/checker-probe.json`. |
| 8–10 | Compare a useful framework with a same-evidence baseline | Proposed experiment; no cases, thresholds or scores claimed. |
| 10 | Semantic verifier receives declaration and output; host checks can depend on inputs | Local `Designs/CC Reference.md` and skills-to-CC mapping. Factory integration remains proposed M2 work. |

## Evaluation limits

The project's fidelity rubric weights stance consistency (30), style recognition (20), edge honesty (20), source transparency (15) and structural completeness (15). It uses three known-position questions, an out-of-scope question and a style sample, with separate answering/judging agents. These are useful checks on resemblance and basic uncertainty, but do not measure scientific-review quality or causal benefit over an evidence-matched baseline.

The published Musk report scores 89/100 while recording a failure to label an inferred position and disclose relevant interests on its edge case. This illustrates why a high aggregate score should not replace inspection of individual failures. We did not rerun the fidelity evaluations or independently verify their reported model identities, scores or cited paper claims. No external-paper statistics are repeated in the deck.

Static inspection of `quality_check.py` found that limitations need only occur somewhere in the file, tension is counted with keywords, and the source check returns success when the section is absent or source types are unmarked. The saved placeholder passes all six functions. This finding does not imply that all generated skills lack substance.

The current template asks for explicit inference labels and minimal source attribution; the Karpathy example also includes instructions to keep source judgments internal. Its date-cutoff behavior and later factual-research protocol need reconciliation before reuse. The English README references a missing Hermes installer, and the main workflow hardcodes Claude-oriented paths despite advertising several runtimes. These are adaptation issues, moved out of the short talk.

## Proposed inclusion

Retain three distinct identities: factory-stage workflow, generated product method, and versioned evidence resources. Convert only a bounded responsibility first. A possible output is a structured engineering-readiness review with supported claims, uncertainty, risks and next tests. Add typed ports, pinned body/resources, declared needs/effects/budgets, failure behavior and independently owned checks before ordinary CC admission.

This follows the existing M2 factory direction. It neither changes maintained M1 contracts nor authorizes broader self-improvement, automatic promotion or source acquisition. The talk uses the latest local M2 planning context instead of carrying forward the older Paper2Agent backup's M1 implementation framing.
