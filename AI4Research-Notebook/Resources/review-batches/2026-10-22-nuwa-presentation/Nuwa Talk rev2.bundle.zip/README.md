---
id: nuwa-presentation
status: completed-documentation
source: ../../../Sources/Prompts/2026-10-22-nuwa-presentation-request.txt; references/source-review.md; ../../Paper2Agent Briefing/presentation/README.md
last_reviewed: 2026-10-22
next_action: Rehearse the six-minute script aloud; choose a bounded framework comparison before implementing any integration
---
# Nuwa: value, method and AI4Research fit

Open [Nuwa Talk rev2.pptx](output/Nuwa%20Talk%20rev2.pptx). There are **eight main slides and two hidden backups**, with a planned **5:50** script in the speaker notes. Timing is an editorial estimate; the talk has not been rehearsed aloud.

This is a separate project beside the Paper2Agent briefing. It follows the latest source builder's short, value-first structure and the existing rev8 deck's editable shapes, 16:9 dimensions, Segoe UI font, cream background, indigo workflow, teal integration, and amber limits. The Paper2Agent README describes revision 9, but that PPTX was absent; the actual visual reference was rev8 and its renders. Its current builder supplied the native-shape helpers. The original files were preserved.

## Talk

| Slide | Takeaway | Time | Visual |
|---|---|---|---|
| 1 | Documented thinking can become reusable research methods | 0:20 | source → workflow → skill |
| 2 | Value comes from reusable analysis and traceable authoring | 0:45 | idea and methodology panels |
| 3 | Six research streams produce models, rules and a runnable skill | 0:50 | research and extraction workflow |
| 4 | The product is a prompt package with supporting evidence | 0:40 | package contents and use-time steps |
| 5 | An engineering perspective can become a repeatable review | 0:55 | worked example: lens → questions → review |
| 6 | Nuwa can inform the capability factory's authoring workflow | 1:00 | authoring versus bounded invocation |
| 7 | Shared sources and model judges limit fidelity evidence | 0:50 | evidence coupling diagram |
| 8 | Compare one useful framework against matched evidence | 0:30 | value, fit, next |
| 9 | Backup: three-arm framework comparison | hidden | editable table |
| 10 | Backup: contract and check adaptations for a CC | hidden | editable table |

The main argument is that Nuwa's research/extraction process could help author source-linked agent methods. A generated skill remains a candidate, requiring a contract, independent checks and ordinary CC admission. The factory mapping is a **proposed M2 extension**, not current M1 behavior or a measured accuracy gain. Persona resemblance is secondary to supported task conclusions and calibrated uncertainty.

## Files and provenance

- [Build script](build_pptx.py): editable native PowerPoint shapes and notes.
- [Speaker script](speaker-script.md): extracted from the delivered deck.
- [Source review and claim ledger](references/source-review.md): repository observations versus our interpretation and proposal.
- [Source receipts](references/source-receipts.json): SHA-256 pins for the reviewed Nuwa files and local design context.
- [Contact sheet](review/contact-sheet.jpg) and [individual slide renders](review/slide-01.png).
- [Quality-checker probe](probe_quality_checker.py) and [recorded result](review/checker-probe.json).
- [Finalization receipt](.build/Nuwa%20Talk%20rev2.validation.json): package, geometry, font, table and Artifact Tool import checks.
- [Render script](render.ps1): exports all ten slides through PowerPoint without saving changes to the deck.

Nuwa was reviewed at commit `7812110bf7e5a2b01b6aa5a738568044121bbfa2`. Selected source snapshots are retained as `.txt` files in `references/`, with the original MIT license. The Nuwa skill was read as source material; it was not installed or activated.

## Validation

All ten slides rendered through PowerPoint and were visually inspected. Revision 2 fixes a wrapped research label, an overflowing example, and the admission-to-runtime connector. The finalizer passed package integrity, ten-slide count, 13.333 × 7.5 inch geometry, reference-font checks, editable backup tables and first-party Artifact Tool import, with no geometry findings. Slides 9 and 10 are hidden; notes and source URLs remain embedded. These checks validate the artifact, not the proposed integration or comparative research claims.

The checker probe passed all six checks on a deliberately empty placeholder skill. That supports a narrow finding about the structural checker; it is not a measurement of Nuwa's task performance. No fidelity tests, skill-to-CC conversion, or factory trial were run.

The notebook-wide validator found two existing broken links in the Paper2Agent README: its missing rev9 deck and `review-rev9/` folder. No Nuwa links or metadata failed. The original Paper2Agent project was left unchanged.

To rebuild, run `build_pptx.py` with the bundled Python runtime. `finalize.mjs` validates a staged PPTX and writes a new output; select a new revision filename before rerunning because the finalizer preserves existing outputs. Then run `render.ps1` against that exact output, inspect every slide, and regenerate the speaker script/contact sheet.
