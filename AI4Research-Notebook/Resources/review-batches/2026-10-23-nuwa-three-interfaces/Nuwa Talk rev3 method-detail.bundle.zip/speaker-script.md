---
id: nuwa-speaker-script
status: planned-unrehearsed
source: output/Nuwa Talk rev3.pptx
last_reviewed: 2026-10-23
next_action: Rehearse the method-detail talk and three-interface factory explanation
---
# Nuwa rev3 speaker script

AI4R value is slide 2. Nine main slides, two hidden backups. Planned 7:20, not rehearsed aloud.

## 1. Main slide

TIME 0:25. Nuwa takes a person and turns their documented thinking into an AI skill. You name someone, Nuwa researches what they wrote, said and did, and the result tells an agent how to reason and respond from that perspective. The promise for AI4Research is access to useful ways of thinking on demand. This talk asks where that adds value, where the approximation fails, and what we should test first.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md

## 2. Main slide

TIME 0:55. AI4Research is the point of studying Nuwa. The reusable lesson is how to turn documented reasoning into a procedure an agent can apply. Nuwa gathers primary material, decisions and criticism; extracts explicit models with failure conditions; and derives concrete research questions from them. We can imitate that method in hypothesis generation, experiment design and evaluation. The result could retain a named perspective or become a neutral research procedure with its intellectual sources visible. Hypothesis work should preserve competing explanations. Experiment design should turn assumptions into evidence questions. Evaluation should retain counterexamples rather than write a persuasive consensus. These are proposed improvements to how AI4R authors and uses reasoning capabilities. Their task benefit still needs measurement; importing a famous voice alone would not establish it.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/extraction-framework.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md
LOCAL CONTEXT
Designs/CC Reference.md; Designs/skills-to-cc-mapping.md. Proposed capability improvement, not implemented support or a measured gain.

## 3. Main slide

TIME 1:00. A mental model is a reusable lens, while a decision rule tells the agent what to do in a particular situation. Nuwa keeps three to seven models. Each must recur across at least two domains, generate judgments on new questions, and distinguish the person's perspective from generic advice. A qualifying model needs supporting scenes, an application and a limitation. Decision heuristics are concrete if-then rules, typically five to ten, with case evidence. The Karpathy example links understanding through construction to rebuilding a minimal core, and contains a data-inspection-before-training rule. We paraphrase the repository's extracted skill here, not independently verified personal statements. Nuwa also records tensions and derives factual research directions from the models. AI4R could imitate this separation of a rationale, an executable step, its evidence requirements and its failure conditions. These qualitative filters select useful candidates; they do not validate scientific correctness.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/extraction-framework.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/examples/andrej-karpathy-perspective/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md

## 4. Main slide

TIME 1:05. A name and target trait first define the scope. The host agent then researches six views of the person. Writings reveal recurring arguments, interviews reveal reasoning under pressure, and short-form expression reveals voice. Criticism provides counterexamples, decisions test statements against actions, and the timeline records change. Each stream saves research with source and confidence, distinguishing direct statements, outside reports and inference. Nuwa prefers primary material, including supplied local sources, and retains unresolved contradictions. If the user provides a strong corpus, it searches only for missing dimensions. Its later quality targets include more than half primary sources, specific model limits, honest boundaries and tensions. Finally, it checks known positions, an unfamiliar question and recognizable voice. AI4R can learn to collect evidence that challenges a candidate rule and retain its provenance, rather than generate a polished method from a few quotations. These are prescribed criteria, not proof that every example meets them.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/extraction-framework.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/fidelity-scorecard.md

## 5. Main slide

TIME 0:45. Take the Karpathy perspective included in the repository. Its documented lenses include the gap between a demo and reliable deployment, difficult tail cases, and learning from real implementations. Suppose an AI4Research agent sees a paper claiming a highly reliable research assistant. A procedure derived from those lenses would ask which task distribution the benchmark covers, what happens in a long run when tools fail, and which evidence can be reproduced. This shows how a model becomes research questions. The response is our illustration derived from the skill, not a quotation or a claim about Karpathy's view of a particular paper. These questions may also arise from a generic checklist. Added value over a generic reviewer is untested, which is why that comparator belongs in the trial.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/examples/andrej-karpathy-perspective/SKILL.md

## 6. Main slide

TIME 0:50. There are four lessons to carry into AI4Research. A public record is incomplete, so we should keep claim-level sources and label inference. A distinctive voice can create authority, so scientific outputs should use evidence rather than a person's name as support. Familiar public-position tests measure a narrow kind of fidelity, so we need new research tasks and independent scoring. Finally, the quality checker counts structure and keywords: our saved empty-content probe passed all six functions, including missing sources. AI4R should fail checks when required evidence is missing and use semantic assessment separately from lint. Separate judging agents still need protection against shared-model biases. Nuwa itself acknowledges many limitations; the issue is whether its checks enforce them in the output.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/fidelity-scorecard.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/scripts/quality_check.py
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/examples/elon-musk-perspective/FIDELITY.md

## 7. Main slide

TIME 1:00. The factory can be understood as one capability-production system with three entry interfaces. First, a gap observed during a run supplies the missing responsibility, task context and failure evidence; diagnosis turns it into a requirement brief. Second, a paper, repository and data supply an existing method to reproduce and adapt. Third, a person's name plus a target trait, such as Karpathy and reliability review, supplies a research intent. That route discovers and prepares relevant sources, then extracts supported models and rules. A name and desired trait alone are not enough to establish a capability. The three routes share a candidate contract, implementation and evidence package, then independent qualification and the existing admission gate. They do not share identical authoring work. Source preparation is separately authorized and pinned before offline build work. A runtime gap does not authorize automatic promotion either. This is a proposed M2 interface direction, starting with flat stages and bounded authoring agents; it does not claim three implemented entry points today.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/extraction-framework.md
LOCAL CONTEXT
User direction, 2026-10-23: three factory inputs. Designs/Capability Capsule Factory Feature.md; Designs/Per Lab Capability Factory Design.md. Proposed M2 extension, not implemented interfaces.

## 8. Main slide

TIME 0:50. Start with one source-rich expert corpus and one bounded responsibility, such as reviewing an agent benchmark. Use Nuwa's extraction method to draft a neutral, source-linked review procedure. Pin the procedure and cutoff, and require outputs to distinguish source-supported rules, framework inference and current task evidence. Compare it against a plain reviewer and a length-matched generic review checklist. All arms get the same expert-source excerpts and task evidence, model, tools and runtime budget. Freeze new tasks and scoring before generation, and use blinded human judgment. Measure supported useful objections, missed failures, calibration and cost. Record authoring cost separately. Retain the procedure only if it improves real review behavior beyond the generic checklist. A persona-voice ablation can follow later if relevant.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/fidelity-scorecard.md
LOCAL CONTEXT
Designs/skills-to-cc-mapping.md; separate proposal, not a revision to the maintained accuracy study.

## 9. Main slide

TIME 0:30. Nuwa shows how documented human reasoning can become a reusable skill. For AI4Research, we should learn the evidence-to-procedure method: preserve sources and disagreement, extract usable rules, and derive concrete investigation steps. A Nuwa-like authoring pipeline could become a reasoning-skill branch of the CC factory. We should improve its assurance with explicit source checks, independent unseen tasks and bounded cost. The next decision is whether one such reviewer improves real AI4R work beyond an equally informed agent. That experiment earns further integration; resemblance to a person does not.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md
LOCAL CONTEXT
Designs/skills-to-cc-mapping.md; Designs/Capability Capsule Factory Feature.md

## 10. Hidden backup

BACKUP. All arms receive the same frozen expert-source excerpts and task evidence. The plain reviewer gets no added procedure. The generic arm gets a length-matched general review checklist. The extracted-method arm gets neutral rules and limits produced through the Nuwa-inspired process. Hold the model, tools, permissions and runtime budgets fixed, freeze unseen tasks and scoring before generation, and blind human assessment. Judge supported useful objections, missed failure modes, unsupported claims, uncertainty, latency and cost. Record corpus preparation and authoring effort separately from runtime cost. This identifies the increment beyond a generic checklist, not the causal effect of each Nuwa phase. A later voice ablation can test whether persona framing helps or hurts. No experimental result is claimed.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/fidelity-scorecard.md
LOCAL CONTEXT
Designs/skills-to-cc-mapping.md; Luna adversarial review, 2026-10-23.

## 11. Hidden backup

BACKUP. A skill is an instruction bundle, not a capsule declaration or runtime permission. For governed use, bind a pinned skill body and evidence resources to a selected agent responsibility. Declare typed task and evidence inputs, a structured critique output, tool needs, effects, budgets and failure behavior. Changes to the worker body require the existing versioning, checks and admission path. The semantic verifier remains declaration-and-output-only; source/input-dependent checks belong in the protected host path. Nuwa's creation workflow can remain an authoring tool while this deployment is tested. Automating that workflow is a later choice, not a prerequisite or the main value proposition.

SOURCES
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/SKILL.md
https://github.com/alchaincyf/nuwa-skill/blob/7812110bf7e5a2b01b6aa5a738568044121bbfa2/references/skill-template.md
LOCAL CONTEXT
Designs/CC Reference.md; Designs/skills-to-cc-mapping.md

