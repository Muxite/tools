# Readable synthetic examples

Every record here is teaching data. None establishes actual execution, scientific truth, permission, admission or measured RSI improvement. Versioned schemas/field contracts define representation; examples illustrate it. Trusted authorship still requires protected runtime code.

## Intent and Requirements

Start with `Request.txt`, `Qualified_Intake.json`, `Intent_IR.json` and `Research_Brief.json`. The Brief preserves accepted intent and attributed compilation defaults; it omits resource availability only for this compilation illustration. `Intent_Topic_Only.json` is structurally valid but unusable and halts. `Intent_Contradictory.json` preserves contradictory constraints requiring clarification. Descriptive files and `Topic_Inspection.md` illustrate readable inspection.

The Intention, Requirements, topic-only and scientific work `*_Subnode_Contract.json` records now includes concrete bindings, authority, budgets, typed ports, guard/policy/configuration/template refs and evidence obligations. Bound plans, observations, contexts, checks, assessments and gates show separate responsibilities. `observed_runtime: false` and null telemetry prevent illustrative observations from claiming measured execution.

## Linked research path

Read `Lifecycle_Research_Brief.json` → `Candidate_Set.json` → `Screening_Result.json` → `Opportunity_Card.json` → `Hypothesis_Blueprint.json` → `POC_Manifest.json` → `Benchmark_Payload.json` → `Evaluation_Verdict.json` → `Delivery_Manifest.json` and `Research_Report.md`.

The lifecycle Brief adds captured synthetic resources without changing user requirements. Hypothesis selects the prepared `Environment_Lock.json`; Builder preserves its declaration. The ZIP is a packaging fixture with readable scripts, not executed scientific code. Separate placeholder evidence explicitly states that no security or execution check was performed. Registered latency/quality rules precede illustrative measurements. Latency worsens while quality holds: scientific FAIL is correctly deliverable. `Science_Assessment.json` and `Gate_Science_Pass.json` illustrate infrastructure acceptance of that conclusion.

## Linked offline RSI path

Read `RSI_Target_Profile.json` → `RSI_Attempt_01.json` → `RSI_Loop_Feedback.json` → `RSI_Referee_Evidence.json` → `RSI_Evidence_Export.json` → `RSI_Admission.json` → `RSI_Activation.json` → `RSI_Rollback.json`.

Parent/child contract and protected target stay fixed. Loop receives counts only. Equal passed counts allow a secondary paired-time comparison; the numerical arrays are invented teaching values, not measured calibration. Referee evidence is custodian-only at runtime. This fixture includes no hidden case contents, per-case identities or answers. Export demonstrates authorized aggregates/redactions. `RSI_Child_Candidate.json` binds the derived child declaration and body pins; protected packaging preserves parent semantic fields. Admission is inactive; human activation/rollback affect future sandbox selection only. Production helper remains unchanged.

The reference validator checks selected structural and relational invariants, including exact reference hashes. It cannot verify actual runtime protection, semantic quality or empirical claims.

## Named planning connections

`Planning_Nodes.json` shows concrete accepted Brief inputs and a future candidate-output connection between separate Search & Ideation and Screening nodes. Each node explicitly assigns internal CC subnodes and protected gates. Declarations and pins are synthetic examples, not admission or observed execution.

## Complete compiler and defaults

`Intention_Node_Contract.json` contains Intention/Requirements work plus separately governed verifier assignments. `Intention_Subnode_Contract.json` and `Requirements_Subnode_Contract.json` bind concrete work. `Gate_Decision.json` accepts intermediate Intent; `Gate_Requirements_Pass.json` accepts the Brief; `Gate_Intention_Compiler_Pass.json` aggregates node acceptance. No synthetic observation establishes measured execution.

`Intent_Permissible_Omissions.json` and `Research_Brief_Defaults.json` illustrate usable purpose/result with missing hardware: only authorized `single_gpu` is applied, attributed to actual `/constraints/0`, with no invented empirical target. Protocol repetition remains in the later Blueprint. `Compiler_Failure_Receipt.json`, `Compiler_No_Output_Checks.json` and `Gate_Compiler_No_Output.json` show a halt without fabricated output references.

## Capsule–routing teaching sequence

[Selected Capsule](Selected_Capsule_Input.json) → [RouteRequest](Route_Request.json) with [protected profile](Model_Selection_Profile.json) and [budget snapshot](Routing_Budget_Snapshot.json) → [frozen decision](Route_Decision.json) → [call record](Model_Call_Record.json). These are synthetic illustrations. The deployment is an example identity, the call has `observed_runtime=false`, and no API/Codex call, live eligibility or measured budget is claimed. Runtime acceptance requires independently captured evidence.
