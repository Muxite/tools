"""Crop figures from the cited papers for the companion's appendix.

Usage: python extract_paper_figs.py     writes figures/papers/<name>.png

Each entry names the paper, the caption text that starts the figure's caption, and whether the figure sits above
its caption (figures) or below it (tables). The crop is the union of the drawings and images between the caption and
the nearest text block beyond them, plus the caption itself, rendered at 220 dpi.
"""
import pathlib

import pymupdf as fitz

HERE = pathlib.Path(__file__).parent
PAPERS = HERE.parent.parent / "papers"
BUNDLE = HERE.parent.parent.parent / "tundle" / "ai4research" / "papers"
OUT = HERE / "papers"

FIGS = [
    # name, arXiv id, caption start, figure above caption (True) or table below caption (False)
    ("dont-offer-pipeline", "2608.01050", "Figure 1: Three-stage selection pipeline", True),
    ("dont-offer-tokens", "2608.01050", "Figure 2: Skill-description token funnel", True),
    ("blind-curator-qc-vs-judge", "2607.07436", "Figure 2: Flag rate on injected defects", True),
    ("more-skills-drop", "2605.24050", "Figure 1: Pass-rate drop when expanding", True),
    ("skillfuzz-depth", "2607.02345", "Fig. 6: Severity is compositional", True),
    ("backfires-contamination", "2608.05810", "Figure 4: Residual contamination", True),
    ("contract2tool-exposure", "2606.07904", "TABLE V", False),
]

# Crops the caption heuristic gets wrong, checked by eye: (x0, y0, x1, y1) in PDF points on the found page.
OVERRIDE = {
    "blind-curator-qc-vs-judge": (100, 78, 512, 357),   # drop the running header above the plot
    "contract2tool-exposure": (54, 183, 558, 284),      # the whole table, down to its last row
}


def pdf_for(arxiv):
    for base in (PAPERS, BUNDLE):
        p = base / f"{arxiv}.pdf"
        if p.exists():
            return p
    raise FileNotFoundError(arxiv)


def crop(page, cap, above):
    blocks = [(fitz.Rect(b[:4]), b[4]) for b in page.get_text("blocks")]
    capblock = next((r for r, t in blocks if r.intersects(cap)), cap)
    art = [fitz.Rect(d["rect"]) for d in page.get_drawings()] + \
          [fitz.Rect(i["bbox"]) for i in page.get_image_info()]
    colx0, colx1 = capblock.x0 - 8, capblock.x1 + 8
    incol = lambda r: r.x1 > colx0 and r.x0 < colx1
    if above:
        # the nearest paragraph (long text block) above the caption bounds the figure
        paras = [r.y1 for r, t in blocks if incol(r) and r.y1 <= capblock.y0 - 2 and len(t.strip()) > 80]
        ceiling = max(paras) if paras else page.rect.y0
        region = [r for r in art if incol(r) and r.y0 >= ceiling - 2 and r.y1 <= capblock.y0 + 3
                  and (r.width > 2 or r.height > 2)]
        if not region:
            return None
        box = fitz.Rect(min(r.x0 for r in region), min(r.y0 for r in region), max(r.x1 for r in region), capblock.y1)
        labels = [r for r, t in blocks if incol(r) and r.y0 >= box.y0 - 14 and r.y1 <= capblock.y0 + 1]
        for r in labels:
            box |= r
    else:
        paras = [r.y0 for r, t in blocks if incol(r) and r.y0 >= capblock.y1 + 2 and len(t.strip()) > 80]
        floor = min(paras) if paras else page.rect.y1
        region = [r for r, t in blocks if incol(r) and r.y0 >= capblock.y1 and r.y1 <= floor]
        region += [r for r in art if incol(r) and r.y0 >= capblock.y1 - 2 and r.y1 <= floor]
        box = fitz.Rect(capblock)
        for r in region:
            box |= r
    box |= capblock
    return box + (-6, -6, 6, 6)


def main():
    OUT.mkdir(exist_ok=True)
    for name, arxiv, caption, above in FIGS:
        doc = fitz.open(pdf_for(arxiv))
        done = False
        for page in doc:
            hits = page.search_for(caption)
            if not hits:
                continue
            box = fitz.Rect(OVERRIDE[name]) if name in OVERRIDE else crop(page, hits[0], above)
            if box is None:
                continue
            pix = page.get_pixmap(dpi=220, clip=box & page.rect)
            pix.save(OUT / f"{name}.png")
            print(f"{name}: {arxiv} p{page.number + 1} {tuple(round(v) for v in box)}")
            done = True
            break
        if not done:
            print(f"{name}: NOT FOUND")


if __name__ == "__main__":
    main()
