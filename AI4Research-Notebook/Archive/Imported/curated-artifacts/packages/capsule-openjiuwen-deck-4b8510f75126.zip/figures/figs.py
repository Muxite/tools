"""Diagrams for the 2026-09-22 deck and its companion, drawn in the style of the 2026-09-15 capsule deck:
DejaVu Sans, colour = stage, style = actor (a model call is tinted with a MODEL tag, code is white with a CODE tag,
a record has a folded corner, an outside party is grey), uppercase group headings, text sized as a ratio of the
canvas so the slide and the report show the same drawing.

Usage: python figs.py        writes every figure (schema, fits, parity, declared, integration, funnel,
lifecycle, milestones) next to this file.
"""
import pathlib

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon  # noqa: E402

from palette import GREY, INK, STAGE, tint  # noqa: E402

HERE = pathlib.Path(__file__).parent
plt.rcParams.update({"font.family": "DejaVu Sans", "savefig.dpi": 300})


def node(ax, x, y, w, h, title, sub="", b=10.0, stage="dispatch", actor="code", ts=1.0, lw=1.4, tag=True):
    c = STAGE[stage]
    ec = GREY if actor == "external" else c
    fc = tint(c, 0.20) if actor == "model" else ("#f4f4f4" if actor == "external" else "white")
    if actor == "record":
        f = min(2.0, w * 0.15, h * 0.3)
        pts = [(x, y), (x + w, y), (x + w, y + h - f), (x + w - f, y + h), (x, y + h)]
        ax.add_patch(Polygon(pts, closed=True, facecolor=fc, edgecolor=ec, linewidth=lw, zorder=2))
        ax.plot([x + w - f, x + w - f, x + w], [y + h, y + h - f, y + h - f], color=ec, lw=lw * 0.8, zorder=3)
    else:
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=0.9", facecolor=fc,
                                    edgecolor=ec, linewidth=lw, zorder=2))
    if sub:
        ax.text(x + w / 2, y + h * 0.63, title, ha="center", va="center", fontsize=b * ts, fontweight="bold",
                color=INK, zorder=4)
        ax.text(x + w / 2, y + h * 0.28, sub, ha="center", va="center", fontsize=b * 0.78 * ts, color=GREY,
                zorder=4, linespacing=1.2)
    else:
        ax.text(x + w / 2, y + h / 2, title, ha="center", va="center", fontsize=b * ts, fontweight="bold",
                color=INK, zorder=4)
    if tag and actor in ("model", "code"):
        filled = actor == "model"
        ax.text(x + 0.8, y + h, "MODEL" if filled else "CODE", ha="left", va="center", fontsize=b * 0.55,
                fontweight="bold", color="white" if filled else c, zorder=5,
                bbox=dict(boxstyle="round,pad=0.22", fc=c if filled else "white", ec=c, lw=0.8))


def arrow(ax, p1, p2, b, color=INK, lw=1.3, dashed=False, rad=0.0):
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=b * 1.1, color=color, lw=lw,
                                 shrinkA=0, shrinkB=0, zorder=1, connectionstyle=f"arc3,rad={rad}",
                                 linestyle=(0, (3, 2)) if dashed else "-"))


def elbow(ax, pts, b, color=INK, lw=1.3, dashed=False):
    xs, ys = zip(*pts[:-1])
    ax.plot(list(xs), list(ys), color=color, lw=lw, zorder=1, linestyle=(0, (3, 2)) if dashed else "-")
    arrow(ax, pts[-2], pts[-1], b, color=color, lw=lw, dashed=dashed)


def label(ax, x, y, text, b, size=0.68, color=INK, ha="center"):
    ax.text(x, y, text, ha=ha, va="center", fontsize=b * size, color=color, style="italic", zorder=6,
            bbox=dict(boxstyle="square,pad=0.15", fc="white", ec="none"))


def heading(ax, x, y, text, b, color, ha="left"):
    ax.text(x, y, text, ha=ha, va="center", fontsize=b * 0.8, fontweight="bold", color=color, zorder=6)


def canvas(width_in, aspect, ratio, draw, path):
    fig = plt.figure(figsize=(width_in, width_in * aspect))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100 * aspect)
    ax.axis("off")
    draw(ax, width_in * ratio)
    fig.savefig(path, facecolor="white", dpi=300)
    plt.close(fig)


# ---------------------------------------------------------------- the schema
TIERS = [
    ("Every capsule", "identity, binding, description, inputs,\noutputs, effects, dependencies, lineage,\nload mode, a hash per file"),
    ("Tested before admission", "pre- and postconditions. Provisional: one passes.\nCertified: every output, blind tests, audited judge"),
    ("Agents add", "a budget, and the exact capsules inside"),
]
RECORDS = [
    ("Certificate", "the level, a verdict per check,\nthe verifier's error rates", "gates"),
    ("Availability events", "what runs may use, and why it changed", "library"),
    ("Run pin", "what was offered, chosen and used", "freeze"),
]


def d_schema(ax, b):
    lib, fz, gt, bd = STAGE["library"], STAGE["freeze"], STAGE["gates"], STAGE["build"]
    heading(ax, 1, 46.5, "MANIFEST  ·  written by the author", b, lib)
    ax.add_patch(FancyBboxPatch((1, 3), 44, 41, boxstyle="round,pad=0,rounding_size=0.9", facecolor="white",
                                edgecolor=lib, linewidth=2.2, zorder=1))
    hs = [13.5, 13.0, 9.0]
    y = 42
    for (tier, fields), h in zip(TIERS, hs):
        y -= h
        ax.add_patch(FancyBboxPatch((2.5, y), 41, h - 1.2, boxstyle="round,pad=0,rounding_size=0.6",
                                    facecolor=tint(lib, 0.08), edgecolor=tint(lib, 0.5), linewidth=1.0, zorder=2))
        ax.text(4, y + h - 3.2, tier, fontsize=b * 0.82, fontweight="bold", color=INK, va="center", zorder=3)
        ax.text(4, y + (h - 1.2) / 2 - 1.6, fields, fontsize=b * 0.72, color=GREY, va="center", zorder=3,
                linespacing=1.25)
        y -= 1.0

    node(ax, 50, 26, 16, 10, "content_hash", "computed,\nnever declared", b, "freeze", "code", ts=0.82)
    arrow(ax, (45, 31), (50, 31), b)
    label(ax, 47.5, 28.3, "hashed", b)

    heading(ax, 70, 46.5, "RECORDS  ·  name the hash", b, gt)
    ys = [34, 21.5, 9]
    for (title, sub, st), yy in zip(RECORDS, ys):
        node(ax, 70, yy, 29, 10, title, sub, b, st, "record", ts=0.82)
        arrow(ax, (70, yy + 5), (66, 31), b, color=GREY, lw=1.0)
    node(ax, 49, 3, 18, 9, "Verifier audit", "error rates, cited\nby every certificate", b, "gates", "record", ts=0.76)
    node(ax, 49, 14.5, 18, 8.5, "Candidate package", "from RSI, carries\na new manifest", b, "build", "record", ts=0.72)
    arrow(ax, (49, 18.7), (45, 18.7), b, color=bd, lw=1.0)
    elbow(ax, [(67, 7.5), (68.4, 7.5), (68.4, 38), (70, 38)], b, color=GREY, lw=0.9, dashed=True)
    ax.text(84.5, 4.6, "plus the gap record and plan step, from\nplanning, and composition reports", ha="center", va="center",
            fontsize=b * 0.6, color=GREY, style="italic", linespacing=1.15)


# ---------------------------------------------------------------- where each part is read
USE = [
    ("intent", "Intent", "sees no capabilities", "intent", "code"),
    ("filter", "Filter", "declared types, effects,\npreconditions, level", "binding", "code"),
    ("rank", "Select and review", "a model binds,\na second reviews fit", "binding", "model"),
    ("freeze", "Freeze", "pins hashes and\nmodel candidates", "freeze", "code"),
    ("run", "Run on agent-core", "hash check, effects,\nin-run gates", "dispatch", "code"),
]
ADMIT = [
    ("gap", "Gap record", "after repair ran out", "binding", "record"),
    ("rsi", "RSI builds", "candidate package", "build", "external"),
    ("ver", "Verifier (a tool)", "a verdict per\npostcondition", "gates", "external"),
    ("rule", "Admission rule", "conjunctive, under\nthe false-pass ceiling", "gates", "code"),
    ("avail", "Availability", "state and reason,\nfor the next run", "library", "code"),
]


def d_fits_slide(ax, b):
    w, h, gap, x0 = 17.4, 10, 2.8, 1.5
    heading(ax, 1, 44, "USE  ·  every run", b, STAGE["binding"])
    heading(ax, 1, 2.2, "ADMIT AND MAKE AVAILABLE  ·  any time, seen from the next run", b, STAGE["gates"])
    pos = {}
    for i, (k, t, s, st, ac) in enumerate(USE):
        x = x0 + i * (w + gap)
        node(ax, x, 28.5, w, h, t, s, b, st, ac, ts=0.8)
        pos[k] = (x, 28.5)
        if i:
            arrow(ax, (x - gap, 33.5), (x, 33.5), b)
    for i, (k, t, s, st, ac) in enumerate(ADMIT):
        x = x0 + i * (w + gap)
        node(ax, x, 5.5, w, h, t, s, b, st, ac, ts=0.8)
        pos[k] = (x, 5.5)
        if i:
            arrow(ax, (x - gap, 10.5), (x, 10.5), b)
    fx = pos["filter"][0]
    rkx = pos["rank"][0]
    elbow(ax, [(rkx + 4, 28.5), (rkx + 4, 23), (pos["gap"][0] + w / 2, 23), (pos["gap"][0] + w / 2, 15.5)], b,
          dashed=True)
    label(ax, rkx + 3, 26, "none fits after repair", b, ha="right")
    ax_ = pos["avail"][0]
    elbow(ax, [(ax_ + w / 2, 15.5), (ax_ + w / 2, 20.5), (fx + w - 4, 20.5), (fx + w - 4, 28.5)], b,
          color=STAGE["library"])
    label(ax, ax_ - 12, 20.5, "next run's candidates", b, color=STAGE["library"])
    rx = pos["run"][0]
    elbow(ax, [(rx + w - 3, 28.5), (rx + w - 3, 15.5)], b, dashed=True, color=GREY)
    label(ax, rx + w - 4.5, 25, "sprint\nfailures", b, color=GREY, ha="right")
    node(ax, rx, 40.5, w, 5.5, "Routing", "", b, "external", "external", ts=0.72)
    arrow(ax, (rx + w / 2, 40.5), (rx + w / 2, 38.5), b, color=GREY)
    label(ax, rx - 2, 43.2, "picks among the frozen\nmodel candidates", b, size=0.6, color=GREY, ha="right")


def d_fits_report(ax, b):
    w, h, gap = 40, 12.5, 4.2
    heading(ax, 3, 104, "USE  ·  every run", b, STAGE["binding"])
    heading(ax, 57, 104, "ADMIT  ·  any time", b, STAGE["gates"])
    pos = {}
    for i, (k, t, s, st, ac) in enumerate(USE):
        y = 86 - i * (h + gap)
        node(ax, 3, y, w, h, t, s, b, st, ac, ts=0.86)
        pos[k] = y
        if i:
            arrow(ax, (23, y + h + gap), (23, y + h), b)
    for i, (k, t, s, st, ac) in enumerate(ADMIT):
        y = 86 - i * (h + gap)
        node(ax, 57, y, w, h, t, s, b, st, ac, ts=0.86)
        pos[k] = y
        if i:
            arrow(ax, (77, y + h + gap), (77, y + h), b)
    fy, gy = pos["filter"], pos["gap"]
    elbow(ax, [(43, fy + h / 2), (50, fy + h / 2), (50, gy + h / 2), (57, gy + h / 2)], b, dashed=True)
    label(ax, 50, (fy + gy) / 2 + h / 2 + 3, "none after repair", b)
    ay = pos["avail"]
    elbow(ax, [(57, ay + h - 3), (48, ay + h - 3), (48, fy + 3), (43, fy + 3)], b, color=STAGE["library"])
    label(ax, 48, (fy + ay) / 2 + 4, "next run's\ncandidates", b, color=STAGE["library"])
    ry = pos["run"]
    arrow(ax, (43, ry + 3), (57, ay + 3), b, dashed=True, color=GREY)
    label(ax, 50, ry - 1.2, "sprint failures", b, color=GREY)
    node(ax, 3, 1.5, w, 7, "Routing", "", b, "external", "external", ts=0.78)
    arrow(ax, (23, 8.5), (23, ry), b, color=GREY)
    label(ax, 45, 5, "picks among the frozen\nmodel candidates", b, size=0.62, color=GREY, ha="left")


# ---------------------------------------------------------------- predicate parity (SCHEMA "Predicate parity")
def frame(ax, x, y, w, h, color, lw=1.2, fill="white", dashed=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=0.9", facecolor=fill,
                                edgecolor=color, linewidth=lw, zorder=0.5,
                                linestyle=(0, (4, 2)) if dashed else "-"))


def d_parity(ax, b):
    lib, bd, dp = STAGE["library"], STAGE["binding"], STAGE["dispatch"]
    heading(ax, 1, 47, "DECLARED ONCE  ·  in the manifest", b, lib)
    heading(ax, 43, 47, "EVALUATED THREE TIMES", b, bd)
    heading(ax, 73, 47, "WHAT A BLOCK MEANS", b, GREY)
    node(ax, 1, 17, 27, 22, "Precondition", "id, check {path, operator, value},\nstate_source, on_unavailable\n\nwritten as data, so code\ncan evaluate it", b,
         "library", "record", ts=0.82)
    rows = [
        (35, "Planner filter", "at planning, before any\nmodel sees the candidate", "binding"),
        (19.5, "Dispatch check", "just before the step runs,\non fresh state", "dispatch"),
        (4, "Capsule body", "its own exit logic,\ninside the capsule", "dispatch"),
    ]
    for y, t, s, st in rows:
        node(ax, 43, y, 25, 10, t, s, b, st, "code", ts=0.82)
    arrow(ax, (28, 34), (43, 40), b, color=bd, lw=1.6)
    arrow(ax, (28, 24), (43, 24.5), b, color=dp, lw=1.6)
    arrow(ax, (28, 18), (43, 9), b, color=GREY, lw=1.3, dashed=True)
    label(ax, 35.5, 30.2, "same evaluator,\nby construction\n(invariant 8)", b, size=0.58)
    label(ax, 35.5, 11.2, "parity tested\nat certification", b, size=0.58, color=GREY)
    outs = [
        (35, "never offered", "at most a one-line\nexclusion reaches the model"),
        (19.5, "step does not run", "state changed or was stale,\nrecorded in the run pin"),
        (4, "exit reports its id", "a disagreement with the gate\nflags predicate drift"),
    ]
    for y, t, s in outs:
        node(ax, 73, y, 26, 10, t, s, b, "external", "external", ts=0.8)
        arrow(ax, (68, y + 5), (73, y + 5), b, color=GREY, lw=1.0)
    ax.text(55.5, 1.2, "tested at the boundary, with state missing and stale, again on every new revision", ha="center", va="center",
            fontsize=b * 0.6, color=GREY, style="italic")


# ---------------------------------------------------------------- declared versus observed
def d_declared(ax, b):
    w, gap, x0 = 21.5, 3.3, 1.5
    heading(ax, 1, 42.3, "OBSERVED  ·  judged by watching use", b, GREY)
    obs = [("Build", "a tool, skill or agent", "external", "external"),
           ("Used in runs", "outputs feed plans\nand claims", "dispatch", "code"),
           ("Outcome watched", "task success, quality\naccumulated from use", "gates", "model"),
           ("Kept or retired", "later, if the judge\nnotices", "library", "code")]
    for i, (t, s, st, ac) in enumerate(obs):
        x = x0 + i * (w + gap)
        node(ax, x, 30, w, 10, t, s, b, st, ac, ts=0.82)
        if i:
            arrow(ax, (x - gap, 35), (x, 35), b)
    ax.text(x0, 26.2, "First check: after runs have used it.  A lenient judge keeps a bad capability without any sign.",
            fontsize=b * 0.66, color=GREY, style="italic", va="center")
    heading(ax, 1, 20.5, "DECLARED  ·  judged against the author's declaration", b, STAGE["library"])
    dec = [("Declare", "pre- and postconditions,\neffects, types", "library", "record"),
           ("Admission tests it", "before any run,\nverdict per check", "gates", "code"),
           ("Filter before choice", "what cannot run\nis never offered", "binding", "code"),
           ("Dispatch compares", "hash, fresh state,\nobserved effects", "dispatch", "code")]
    for i, (t, s, st, ac) in enumerate(dec):
        x = x0 + i * (w + gap)
        node(ax, x, 6, w, 10, t, s, b, st, ac, ts=0.82)
        if i:
            arrow(ax, (x - gap, 11), (x, 11), b)
    ax.text(x0, 2.2, "First check: before any run.  Every later check has a declared target, and a judge's error rate is recorded.",
            fontsize=b * 0.66, color=INK, style="italic", va="center")


# ---------------------------------------------------------------- integration with openJiuwen
def d_integration(ax, b):
    lib, bd, dp = STAGE["library"], STAGE["binding"], STAGE["dispatch"]
    heading(ax, 1, 52, "IMPORTED AS\nPROVISIONAL", b, GREY)
    for i, t in enumerate(["ToolCard", "MCP server", "SKILL.md", "A2A agent", "Science-\nDiscovery"]):
        node(ax, 1, 41 - i * 7, 13, 5.5, t, "", b, "external", "external", ts=0.66)
    frame(ax, 18, 11, 26, 43, lib, lw=2.0, fill=tint(lib, 0.06))
    heading(ax, 19.5, 51.5, "CAPSULE LAYER  ·  new", b, lib)
    comps = ["Importer", "Provider", "Librarian", "Store (by hash)", "Admission rule"]
    cy = {}
    for i, t in enumerate(comps):
        y = 42 - i * 7
        node(ax, 20.5, y, 21, 5.4, t, "", b, "library", "code", ts=0.7, tag=False)
        cy[t] = y + 2.7
    for i in range(5):
        arrow(ax, (14, 43.75 - i * 7), (20.5, cy["Importer"]), b, color=GREY, lw=0.8)
    frame(ax, 50, 11, 49, 43, dp, lw=2.0, fill=tint(dp, 0.05))
    heading(ax, 51.5, 51.5, "AGENT-CORE  ·  existing", b, dp)
    frame(ax, 52, 31, 45, 17.5, bd, lw=1.4, fill="white")
    heading(ax, 53.5, 46.3, "SYMPHONY", b, bd)
    node(ax, 54, 33, 19, 10, "Fingerprints, graph", "inventory, can_feed edges", b, "binding", "code", ts=0.7)
    node(ax, 77, 33, 18, 10, "Planner", "reads id, name,\ndescription", b, "binding", "model", ts=0.7)
    arrow(ax, (73, 38), (77, 38), b, color=bd, lw=1.2)
    frame(ax, 52, 13, 45, 15.5, dp, lw=1.4, fill="white")
    heading(ax, 53.5, 26.3, "HARNESS", b, dp)
    node(ax, 54, 14.5, 13, 8, "Binder", "loads by name", b, "dispatch", "code", ts=0.66, tag=False)
    node(ax, 68.5, 14.5, 13, 8, "Rail", "tool-call spans", b, "dispatch", "code", ts=0.66, tag=False)
    node(ax, 83, 14.5, 12.5, 8, "Trajectories", "run pins, via\na new rail", b, "dispatch", "code", ts=0.66, tag=False)
    arrow(ax, (41.5, cy["Provider"]), (54, 40.5), b, color=bd, lw=1.4)
    label(ax, 46.5, 46.2, "CapabilityProvider:\nskills, subagents, agents", b, size=0.62, color=bd)
    arrow(ax, (41.5, cy["Librarian"]), (54, 35.5), b, color=lib, lw=1.4)
    label(ax, 47.8, 31.6, "SkillGraphUpdater", b, size=0.62, color=lib)
    arrow(ax, (41.5, cy["Store (by hash)"]), (54, 19), b, color=dp, lw=1.4)
    label(ax, 47.8, 25.4, "load by hash,\nfrom the store", b, size=0.62, color=dp)
    elbow(ax, [(75, 14.5), (75, 8.5), (46, 8.5), (46, cy["Admission rule"]), (41.5, cy["Admission rule"])], b,
          color=GREY, lw=1.1)
    label(ax, 62, 8.5, "tool calls against declared effects", b, size=0.62, color=GREY)
    heading(ax, 1, 4.5, "TOOLS IT USES", b, GREY)
    node(ax, 18, 1, 12, 5, "RSI", "", b, "external", "external", ts=0.7)
    node(ax, 32, 1, 12, 5, "Verifier", "", b, "external", "external", ts=0.7)
    arrow(ax, (24, 6), (24, 14), b, color=GREY, lw=1.0)
    arrow(ax, (38, 6), (38, 14), b, color=GREY, lw=1.0)
    node(ax, 83, 1, 14, 5, "Routing", "", b, "external", "external", ts=0.7)
    arrow(ax, (90, 6), (90, 13), b, color=GREY, lw=1.0)
    label(ax, 81.5, 3.5, "picks the model at run time", b, size=0.54, color=GREY, ha="right")


# ---------------------------------------------------------------- selection funnel
def d_funnel(ax, b):
    bd, gt = STAGE["binding"], STAGE["gates"]
    stages = [
        ("Available", "active capsules in\nthe run's snapshot", "library", "code", 10, 0),
        ("Filter", "declared types, effects,\npreconditions, level", "binding", "code", 10, 6),
        ("Bind", "a model reads name,\ndescription, level", "binding", "model", 4, 0),
        ("Fit review", "a second model,\nbounded repair", "binding", "model", 1, 0),
        ("Freeze", "pins hash, certificate,\nmodel candidates", "freeze", "code", 1, 0),
    ]
    w, gap, x0 = 17.4, 2.8, 1.5
    ax.text(x0, 40, "Candidates for one plan step entering each stage (illustrative)", fontsize=b * 0.62,
            color=GREY, style="italic", va="center")
    for i, (t, s, st, ac, n, cut) in enumerate(stages):
        x = x0 + i * (w + gap)
        node(ax, x, 17, w, 10, t, s, b, st, ac, ts=0.8)
        if i:
            arrow(ax, (x - gap, 22), (x, 22), b)
        for k in range(n):
            cx, cy = x + 1 + (k % 5) * 3.2, 34 - (k // 5) * 2.8
            removed = k >= n - cut
            ax.add_patch(FancyBboxPatch((cx, cy), 2.6, 2.0, boxstyle="round,pad=0,rounding_size=0.3",
                                        facecolor="white" if removed else tint(bd, 0.45),
                                        edgecolor=GREY if removed else bd, lw=0.6, zorder=2))
            if removed:
                ax.plot([cx + 0.4, cx + 2.2], [cy + 0.3, cy + 1.7], color=gt, lw=1.0, zorder=3)
                ax.plot([cx + 0.4, cx + 2.2], [cy + 1.7, cy + 0.3], color=gt, lw=1.0, zorder=3)
    xf = x0 + (w + gap)
    ax.text(xf + w / 2, 29.3, "removed by code: never\noffered, one line at most", ha="center", va="center",
            fontsize=b * 0.56, color=gt, style="italic", linespacing=1.1)
    xb = x0 + 3 * (w + gap)
    elbow(ax, [(xb + w / 2, 17), (xb + w / 2, 11), (xb + w + 3.5, 11)], b, dashed=True)
    node(ax, xb + w + 3.5, 7.5, 16.5, 7, "Gap record", "to RSI", b, "binding", "record", ts=0.7)
    label(ax, xb + w / 2 - 1, 13.2, "none fits after repair", b, size=0.58, ha="right")
    ax.text(x0, 10.5, "In AI4Research today the binding model receives every eligible candidate's full catalog row,",
            fontsize=b * 0.6, color=INK, va="center")
    ax.text(x0, 7.5, "and again on its repair, so each capsule removed by code is context no model call pays for.",
            fontsize=b * 0.6, color=INK, va="center")
    ax.text(x0, 3.2, "Don't Offer What Can't Be Done: its gate cut 59.1% of description tokens after relevance matching,",
            fontsize=b * 0.6, color=GREY, va="center")
    ax.text(x0, 0.6, "90.5% with matching (10 skills, one month). Here the saving is measured in M2, not assumed.",
            fontsize=b * 0.6, color=GREY, va="center")


# ---------------------------------------------------------------- admission and availability
def d_lifecycle(ax, b):
    gt, lib = STAGE["gates"], STAGE["library"]
    heading(ax, 1, 42.3, "ADMISSION  ·  what is tested", b, gt)
    row = [("Candidate", "from RSI, a person,\nor an importer", "build", "record"),
           ("Provisional tests", "loads, within effects,\none postcondition", "gates", "code"),
           ("Provisional", "offered only to steps\nthat check downstream", "library", "record"),
           ("Certified tests", "every output, blind\nsuite, audited judge,\nprecondition parity", "gates", "code"),
           ("Certified", "offered to\nevery step", "library", "record")]
    w, gap, x0 = 17.4, 2.8, 1.5
    for i, (t, s, st, ac) in enumerate(row):
        x = x0 + i * (w + gap)
        node(ax, x, 27, w, 12, t, s, b, st, ac, ts=0.78)
        if i:
            arrow(ax, (x - gap, 33), (x, 33), b)
    heading(ax, 99, 19.3, "AVAILABILITY  ·  one event per change", b, lib, ha="right")
    states = [("active", 1.5), ("admitted_inactive", 21.5), ("outside_cap", 41.5), ("retired", 61.5), ("revoked", 81.5)]
    for t, x in states:
        node(ax, x, 9, 17, 7, t, "", b, "library", "code", ts=0.72, tag=False)
    notes = [(11.5, "no predecessor, improves on\nthe baseline, or a rollback"),
             (31.5, "no gain yet, expired\ncertificate, revalidating"),
             (51.5, "cap evicted, bound only\nby an explicit pin"),
             (71.5, "quality or superseded,\nnever deleted"),
             (91.5, "blocks new runs,\ntaints running outputs")]
    for x, t in notes:
        ax.text(x - 1, 4.2, t, ha="center", va="center", fontsize=b * 0.56, color=GREY, linespacing=1.15)
    xp, xc = x0 + 2 * (w + gap) + w / 2, x0 + 4 * (w + gap) + w / 2
    ax.plot([xc, xc, xp], [27, 23.5, 23.5], color=lib, lw=1.1, zorder=1)
    elbow(ax, [(xp, 27), (xp, 23.5), (10, 23.5), (10, 16)], b, color=lib, lw=1.1)
    arrow(ax, (30, 23.5), (30, 16), b, color=lib, lw=1.1)
    label(ax, 58, 23.5, "admitted: active, or inactive until it improves", b, size=0.58, color=lib)


# ---------------------------------------------------------------- milestones
def d_milestones(ax, b):
    ms = [("M1", "store, importer,\nprovisional admission", "library"),
          ("M2", "preconditions in the\nfilter, measured", "binding"),
          ("M3", "certification,\nverifier audit", "gates"),
          ("M4", "availability, gaps,\nlibrarian", "library"),
          ("M5", "agents as\ncomposites", "build")]
    w, gap = 18.5, 1.6
    for i, (m, t, st) in enumerate(ms):
        x = 1 + i * (w + gap)
        c = STAGE[st]
        pts = [(x, 3), (x + w - 3, 3), (x + w, 11), (x + w - 3, 19), (x, 19), (x + 3, 11)] if i else \
              [(x, 3), (x + w - 3, 3), (x + w, 11), (x + w - 3, 19), (x, 19)]
        ax.add_patch(Polygon(pts, closed=True, facecolor=tint(c, 0.16), edgecolor=c, lw=1.4, zorder=2))
        ax.text(x + w / 2 + 0.5, 15, m, ha="center", va="center", fontsize=b * 1.0, fontweight="bold", color=c)
        ax.text(x + w / 2 + 0.8, 8.5, t, ha="center", va="center", fontsize=b * 0.58, color=INK, linespacing=1.2)

# ---------------------------------------------------------------- dependencies (companion Table 14)
def d_deps(ax, b):
    lib = STAGE["library"]
    node(ax, 1, 2, 21, 60, "Capsule\nlayer", "", b, "library", "code", ts=1.0, tag=False)
    ax.text(11.5, 20, "store\nimporter\nadmission rule\nprovider\nlibrarian", ha="center", va="center",
            fontsize=b * 0.66, color=GREY, linespacing=1.4)
    heading(ax, 50.5, 63.8, "GIVES  (brown, above)   ·   NEEDS  (grey, below)", b, GREY, ha="center")
    rows = [  # neighbour, what the capsule layer gives, what it needs
        ("Symphony", "available skills, subagents and agents, with hash and level", "its planner, fed by the provider"),
        ("agent-core", "only admitted hashes to load, declared effects", "loading, tool-call spans, trajectories"),
        ("RSI", "gap records counted over runs, evidence on exact versions", "candidate packages with tests from another author"),
        ("Verification", "the conditions to test, run pins to trace failures", "verdicts per check, the verifier audit, sprint failures"),
        ("Routing", "the models each capsule's evidence covers", "the model that ran, recorded in the run pin"),
        ("Screening tool", "declared contracts of capsules that share a context", "composition reports on risky combinations"),
    ]
    for i, (name, give, need) in enumerate(rows):
        y = 52.5 - i * 10
        node(ax, 79, y, 20, 8, name, "", b, "external", "external", ts=1.0)
        arrow(ax, (22, y + 5.3), (79, y + 5.3), b, color=lib, lw=1.3)
        arrow(ax, (79, y + 2.7), (22, y + 2.7), b, color=GREY, lw=1.3)
        ax.text(50.5, y + 7.0, give, ha="center", va="center", fontsize=b * 0.78, color=lib)
        ax.text(50.5, y + 1.0, need, ha="center", va="center", fontsize=b * 0.78, color=GREY)


# ---------------------------------------------------------------- spatiotemporal composability (SCHEMA section)
def d_compose(ax, b):
    lib, bd, fz, gt, dp = STAGE["library"], STAGE["binding"], STAGE["freeze"], STAGE["gates"], STAGE["dispatch"]
    heading(ax, 1, 47.5, "SPACE  \u00b7  what a capsule needs", b, bd)
    node(ax, 1, 27, 21, 11, "Capsule A", "declares inputs,\npreconditions, dependencies", b, "binding", "record", ts=0.8)
    node(ax, 30, 27, 17, 11, "Capsule B", "a dependency,\npinned by hash", b, "binding", "record", ts=0.8)
    arrow(ax, (22, 32.5), (30, 32.5), b, color=bd, lw=1.4)
    label(ax, 26, 35.4, "depends on", b, size=0.6, color=bd)
    node(ax, 4, 6, 40, 10, "Availability event", "B revoked: A moves to revalidation_pending\nbefore any new run binds it", b, "library",
         "record", ts=0.8)
    arrow(ax, (38.5, 27), (34, 16), b, color=lib, lw=1.2)
    arrow(ax, (12, 16), (12, 27), b, color=lib, lw=1.2, dashed=True)
    label(ax, 25, 21.5, "reacts to the change", b, size=0.6, color=lib)
    ax.plot([50.5, 50.5], [2, 48], color="#cccccc", lw=1.0, zorder=0)
    heading(ax, 53, 47.5, "TIME  \u00b7  what a capsule changes", b, fz)
    xs = [53, 68, 83]
    for i, (t, sub) in enumerate([("revision 1", "superseded, kept"), ("revision 2", "active"), ("revision 3", "admitted, inactive\nuntil it improves")]):
        node(ax, xs[i], 35, 14, 7.5, t, sub, b, "library", "record", ts=0.7)
        if i:
            arrow(ax, (xs[i - 1] + 14, 38.75), (xs[i], 38.75), b, color=lib, lw=1.2)
    ax.add_patch(FancyBboxPatch((66.5, 25.5), 17, 6, boxstyle="round,pad=0,rounding_size=0.6", facecolor=tint(fz, 0.15),
                                edgecolor=fz, lw=1.1, zorder=1))
    ax.text(75, 28.5, "a run pins revision 2\nand keeps it to the end", ha="center", va="center", fontsize=b * 0.58, color=INK)
    arrow(ax, (75, 31.5), (75, 35), b, color=fz, lw=1.0)
    ax.add_patch(FancyBboxPatch((53, 3), 21.5, 17, boxstyle="round,pad=0,rounding_size=0.8", facecolor=tint(gt, 0.12),
                                edgecolor=gt, lw=1.3, zorder=1))
    ax.add_patch(FancyBboxPatch((77.5, 3), 21.5, 17, boxstyle="round,pad=0,rounding_size=0.8", facecolor=tint(dp, 0.10),
                                edgecolor=dp, lw=1.3, linestyle=(0, (4, 2)), zorder=1))
    ax.text(63.75, 17, "INSIDE the boundary", ha="center", va="center", fontsize=b * 0.66, fontweight="bold", color=gt)
    ax.text(63.75, 10, "inverse: restores the\nprior state (a scratch path\nthe run alone can write)", ha="center", va="center",
            fontsize=b * 0.6, color=INK, linespacing=1.2)
    ax.text(88.25, 17, "OUTSIDE the boundary", ha="center", va="center", fontsize=b * 0.66, fontweight="bold", color=dp)
    ax.text(88.25, 10, "compensation: restores up\nto a declared equivalence\nirreversible: only where allowed", ha="center",
            va="center", fontsize=b * 0.6, color=INK, linespacing=1.2)
    ax.text(76, 22.3, "every write, execute and network effect declares its undo", ha="center", va="center",
            fontsize=b * 0.58, color=GREY, style="italic")


if __name__ == "__main__":
    canvas(12.0, 0.49, 1.55, d_schema, HERE / "schema.png")
    canvas(12.0, 0.47, 1.45, d_fits_slide, HERE / "fits-slide.png")
    canvas(7.3, 1.08, 1.6, d_fits_report, HERE / "fits-report.png")
    canvas(12.0, 0.49, 1.5, d_parity, HERE / "parity.png")
    canvas(12.0, 0.44, 1.5, d_declared, HERE / "declared.png")
    canvas(12.0, 0.56, 1.45, d_integration, HERE / "integration.png")
    canvas(12.0, 0.43, 1.45, d_funnel, HERE / "funnel.png")
    canvas(12.0, 0.44, 1.45, d_lifecycle, HERE / "lifecycle.png")
    canvas(12.0, 0.2, 1.45, d_milestones, HERE / "milestones.png")
    canvas(12.0, 0.65, 1.45, d_deps, HERE / "deps.png")
    canvas(12.0, 0.5, 1.45, d_compose, HERE / "compose.png")
    print("wrote all figures")
