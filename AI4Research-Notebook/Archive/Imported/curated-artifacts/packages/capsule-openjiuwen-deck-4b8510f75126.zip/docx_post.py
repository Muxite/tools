"""Post-process the companion .docx: 0.6 in margins, design figures at full text width, paper figures in the
appendix at 62% width, 10.5 pt table and caption text.
Usage: python docx_post.py <file.docx>"""
import re
import sys
import zipfile
from pathlib import Path

src = Path(sys.argv[1])
MARGIN = 864                      # twips, 0.6 in
TEXT_W = int((8.5 - 1.2) * 914400)  # EMU, US Letter minus margins
data = {}
with zipfile.ZipFile(src) as z:
    infos = z.infolist()
    for i in infos:
        data[i.filename] = z.read(i.filename)
doc = data["word/document.xml"].decode("utf-8")
doc = re.sub(r'<w:pgMar [^>]*/>', f'<w:pgMar w:top="{MARGIN}" w:right="{MARGIN}" w:bottom="{MARGIN}" '
             f'w:left="{MARGIN}" w:header="432" w:footer="432" w:gutter="0"/>', doc)


MAX_H = int(6.4 * 914400)          # a tall figure is capped in height so it fits under its heading


def sizer(width, max_h):
    def widen(m):
        cx, cy = int(m.group(2)), int(m.group(3))
        w = TEXT_W if cx > 3 * cy else width      # a wide, short crop (a table) needs the full width to be legible
        if cy * w / cx > max_h:
            w = round(cx * max_h / cy)
        return f'{m.group(1)}cx="{w}" cy="{round(cy * w / cx)}"'
    return widen


def size_figures(part, width, max_h):
    part = re.sub(r'(<wp:extent )cx="(\d+)" cy="(\d+)"', sizer(width, max_h), part)
    return re.sub(r'(<a:ext )cx="(\d+)" cy="(\d+)"', sizer(width, max_h), part)


# the design's own figures fill the text width; figures cropped from papers (after the Appendix heading) are smaller
cut = doc.find("Appendix: figures from the papers")
body, appendix = (doc, "") if cut < 0 else (doc[:cut], doc[cut:])
doc = size_figures(body, TEXT_W, MAX_H) + size_figures(appendix, round(TEXT_W * 0.62), int(4.2 * 914400))
K = (8.5 - 1.2) * 1440 / 9648    # tables are built 6.7 in wide; stretch them to the text width
doc = re.sub(r'(<w:(?:tblW|gridCol|tcW) w:w=")(\d+)"', lambda m: f'{m.group(1)}{round(int(m.group(2)) * K)}"', doc)
doc = doc.replace('<w:sz w:val="19"/>', '<w:sz w:val="21"/>').replace('<w:szCs w:val="19"/>', '<w:szCs w:val="21"/>')
data["word/document.xml"] = doc.encode("utf-8")
sty = data["word/styles.xml"].decode("utf-8").replace('w:val="19"', 'w:val="21"')
data["word/styles.xml"] = sty.encode("utf-8")
tmp = src.with_suffix(".tmp")
with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
    for i in infos:
        z.writestr(i, data[i.filename])
tmp.replace(src)
print("post-processed", src)
