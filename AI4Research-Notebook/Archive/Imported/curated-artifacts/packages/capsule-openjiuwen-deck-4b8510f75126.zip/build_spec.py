"""Build deck.json for the 2026-09-22 workshop from the content below, then run:
    tundlekit deck build deck.json -o "Capability Capsule - Workshop 2026-09-22.pptx"
Slide prose: no em dashes, semicolons, contractions or first person. Notes are first person and short enough to say.
Source of truth: SCHEMA.md v1.6. Every cited paper was read in full by Muk and by an agent; every number is checked
in verify/PAPER-LEDGER.md. Code claims checked in source on 2026-09-21 and 2026-09-22.
Diagrams: python figures/figs.py, and figures/extract_paper_figs.py for the companion's appendix. The companion,
companion.md, has one ## heading per content-slide title, in the same order.
"""
import json
from pathlib import Path


def content(eyebrow, title, stage, source, body, notes, thus=None, demo=None, insert=False):
    s = {"type": "content", "eyebrow": eyebrow, "title": title, "stage": stage, "source": source,
         "body": body, "notes": notes}
    if thus:
        s["thus"] = thus
    if demo:
        s["demonstrated_by"] = {"paper": demo[0], "setup": demo[1]}
    if insert:
        s["insert"] = True
    return s


def table(rows, widths=None):
    b = {"kind": "table", "rows": rows}
    if widths:
        b["widths"] = widths
    return b


def figure(path):
    return {"kind": "figure", "path": path}


def say(time, text, asked=None):
    n = {"time": time, "say": text}
    if asked:
        n["asked"] = asked
    return n


def backup(title, stage, source, body):
    return content("Backup", title, stage, source, body, say("0:20", "Shown only if asked."), insert=True)


slides = [
    {"type": "title", "title": "Capability Capsule",
     "subtitle": "A schema every capability declares, so every check has a target",
     "byline": "Muk Chunpongtong · Design workshop, 22 September 2026",
     "notes": say("0:20", "Capability Capsule is a schema: the contract every capability in the new AI4Research system "
                          "declares, so the tools that build, check, choose and run capabilities can do their job. "
                          "Everything here is design. Nothing is built yet.")},
    content("Summary", "a to g in one page", "external", "companion.md, SCHEMA.md v1.6",
            table([
                ["Req.", "Answer", "Slides"],
                ["a Function", "declare, admit, make available. Safer than watching", "3-8"],
                ["b Architecture", "one manifest, two levels, predicate parity, imports", "9-14"],
                ["c Position", "planning, freeze, dispatch, claims, on agent-core", "15-18"],
                ["d Dependencies", "one agreed record per neighbour", "19-20"],
                ["e Similar designs", "others watch, this schema declares and tests", "21"],
                ["f Advantages", "safer, cheaper selection, each falsifiable", "22-25"],
                ["g Feasibility", "every part exists, and ownership is for discussion", "26-27"],
            ], [3.2, 7.6, 1.4]) | {"size": 13},
            say("0:30", "The whole talk on one slide. One idea runs through all seven answers: declare first, so every "
                        "check has a target, and check before any run uses a capability."),
            thus="declare first, so every check has a target"),
    content("a · Function", "Capability Capsule is a schema, not a tool", "library", "Supervisor, 2026-09-18 and 2026-09-21",
            [table([
                ["", "What happens", "Who"],
                ["Declare", "a capability states its conditions, outputs and effects", "its author, in the manifest"],
                ["Admit", "a version is kept only if tests of its declared job pass", "the admission rule decides, the verifier measures"],
                ["Make available", "which kept versions a run may bind", "the librarian writes it, the run pins it"],
                ["Compose", "add, replace, roll back, remove without breaking others", "the capsule layer, from the manifest"],
            ], [2.6, 5.8, 3.8]) | {"size": 13},
             {"kind": "lines", "size": 15, "items": [
                 "Scheme is the supervisor's word for this schema plus the rules the capsule layer applies with it",
                 "RSI builds capsules. A run pin records what a run used. The librarian keeps the library",
             ]}],
            say("0:35", "The supervisor's line: Capability Capsule is a scheme, and the verifier is a tool it uses. The "
                        "schema defines the rules, and the capsule layer's code applies them on agent-core. Building is "
                        "RSI's, measuring is the verifier's, choosing models is routing's, running is agent-core's.",
                ["Capsules change code, prompts and manifests, never model weights",
                 "AI4Research itself is not a capsule, by the supervisor's ruling"]),
            thus="a scheme that uses tools such as the verifier, and is never a tool itself"),
    content("a · Function", "What every capability declares, in one manifest", "library", "SCHEMA.md A1. Illustrative",
            {"kind": "lines", "mono": True, "size": 13.5, "items": [
                "capability_id: fetch-paper-fulltext        revision: 3        capability_type: tool",
                "inputs:  paper_id (arxiv_id)                outputs: fulltext (document_text)",
                "effects: network read  export.arxiv.org     write  workspace/papers/  (undo: delete the file)",
                "preconditions:",
                "  network-allowed   run.policy.network includes export.arxiv.org   evaluable_at: planning",
                "  id-resolves       inputs.paper_id resolves in arXiv             evaluable_at: dispatch",
                "postconditions:",
                "  text-present      fulltext has at least one page of text         anchor: deterministic",
                "  title-matches     title matches the arXiv record                 anchor: reference",
                "dependencies: arXiv API, pinned by endpoint and version     load_mode: invoked",
                "components: fetch_fulltext.py  sha256 ...     lineage: supersedes revision 2",
            ]},
            say("0:50", "This is the schema, filled in for one AI4Research capability, fetching a paper's full text. It "
                        "declares what it needs, what it guarantees and what it touches. The filter reads the effects, the "
                        "types and the first precondition, which can be checked at planning. Dispatch checks both "
                        "preconditions. The verifier runs the two postconditions. The hash covers the file.",
                ["Tests, the certificate and availability are records outside the manifest that name its hash",
                 "The full field list is in SCHEMA.md A1 and the backup slide"]),
            thus="every later slide is about who reads which of these lines"),

    content("a · Function", "Composable in space and time, by declaration", "library",
            "SCHEMA.md Spatiotemporal composability. Cordis (2608.25512), SkillFuzz (2607.02345)",
            figure("figures/compose.png"),
            say("0:55", "A library that changes while it is used needs two guarantees. In space, each capsule declares what "
                        "it needs, so when a dependency is revoked its dependents are revalidated before a new run binds them. "
                        "In time, each declares how its effects are undone, so versions can be replaced and rolled back. The "
                        "terms come from Cordis. Reversal only holds inside a boundary, so the schema asks which side each "
                        "effect is on. And unlike Cordis, composition happens between runs, because a run keeps what it pinned.",
                ["Combinations are screened, not certified: the schema supplies SkillFuzz's contracts and records its findings",
                 "SkillFuzz: severe drift 4.7% with one skill loaded, 66.5% with five. 80.6% of high-risk plan flags confirmed in execution",
                 "A step never co-loads a set confirmed as high-risk"]),
            thus="needs and undo are declared, so the library can change safely around a run"),
    content("a · Function", "Every tool the schema serves is one the research needs", "library",
            "SCHEMA.md. Papers read in full, numbers in verify/PAPER-LEDGER.md",
            table([
                ["Tool", "The failure it answers", "Paper"],
                ["Admission gate", "215 of 222 self-built tools failed every held-out test of their job", "Beyond Task Completion"],
                ["Executability filter", "7.8% of replays picked a skill that could not run", "Don't Offer What Can't Be Done"],
                ["Verifier audit", "a lenient judge stopped retirement, and the count hid it", "The Blind Curator"],
                ["Improvement check", "without it, 8 points lower. Later cleanup won back 1.7 of 12.3", "When Self-Evolution Backfires"],
                ["Librarian", "harsh retirement fell below the no-skill floor", "Library Drift"],
                ["Composition screening", "drift 4.7% with one skill, 66.5% with five. 80.6% of flags confirmed", "SkillFuzz"],
            ], [2.6, 6.2, 3.4]),
            say("0:40", "This is why the schema exists. Each tool the new system needs answers a failure someone "
                        "measured, and each tool needs the same facts about a capability. The schema is those facts. "
                        "A field no tool reads is removed.",
                ["Libraries are worth having: Alita-G's lifted GAIA pass@1 from 75.15% to 83.03%, on its own build set",
                 "Beyond Task Completion: Haiku 4.5, 3 tool-creating protocols, 3 seeds. Backfires: one run",
                 "Blind Curator: bias injected on a deterministic grader, 3 seeds"]),
            thus="the schema is the set of facts every one of these tools needs"),
    content("a · Function", "Declaring first is safer than watching afterwards", "gates", "companion.md",
            figure("figures/declared.png"),
            say("0:45", "Two ways to judge a capability. Watch it in use, and retire it if the judge notices, which "
                        "means runs have already built on it. Or declare what it needs and guarantees, test that at "
                        "admission, and check it again before choice and before dispatch. The second gives every "
                        "check a target, and a guarantee relative to the declaration.",
                ["In a frozen plan an unrunnable capsule fails its step at dispatch, and the plan cannot swap it",
                 "Observation keeps a role: held-out tests, retirement and audits all observe against the declaration",
                 "A blocked capsule could not have completed, by construction. Observation only gives a rate, afterwards",
                 "In AI4Research a frozen step cannot swap its capsule, so a wrong output becomes a wrong claim",
                 "A declaration can be false, so admission compares declared and observed effects, and certification tests parity",
                 "Passing a precondition grants no right to any effect"]),
            thus="every later check has a declared target, and the first one runs before any use"),
    content("a · Function", "Where declared and observed checking differ", "gates", "companion.md",
            table([
                ["", "Observed", "Declared, this schema"],
                ["First check", "after runs used it", "before any run uses it"],
                ["Reference for correct", "task success, quality from use", "the author's declaration, tested"],
                ["What cannot run", "offered, then fails or is refused", "removed by code before any model chooses"],
                ["A lenient judge", "keeps bad capabilities with no sign", "its audited error rate is recorded, or its verdict does not count"],
                ["A wrong output", "becomes a claim the frozen plan cannot undo", "traced from the claim to the exact binding"],
            ], [2.8, 4.6, 4.8]),
            say("0:40", "Five differences. The first check moves before use. The reference becomes the declaration. "
                        "What cannot run is never offered. A lenient judge shows up in the record. And a wrong output "
                        "traces back to the exact capsule that produced it.",
                ["Rows one and two: Beyond Task Completion. Row three: Don't Offer What Can't Be Done",
                 "Row four: The Blind Curator. Row five: the run pin"]),
            thus="the declared column checks first, and leaves a record at every step"),
    content("b · Architecture", "One manifest, one hash, records that name it", "library", "SCHEMA.md Part A and B",
            figure("figures/schema.png"),
            say("0:40", "The author writes one manifest. Its hash covers every file. Everything else sits outside and "
                        "names that hash: the certificate, availability events, the verifier audit and the run pin. "
                        "A record cannot contain its own hash, and retiring a capsule must never change it.",
                ["Store, importer, admission rule, provider and librarian are the capsule layer's code"])),
    content("b · Architecture", "The records around the manifest, and who writes each", "library", "SCHEMA.md Part A and B",
            table([
                ["Record", "Holds", "Writer, readers"],
                ["Certificate", "level, a verdict per check, observed effects, parity, verifier error", "admission rule, for planner and librarian"],
                ["Availability event", "what runs may use, and a typed reason", "librarian, for the planner"],
                ["Verifier audit", "false-pass and false-fail rates", "verification, for admission"],
                ["Run pin", "offered, blocked, chosen, hashes, model, exits, tokens, claims", "the run, for everyone"],
                ["Candidate package", "manifest, body, tests from another author", "RSI, for admission"],
                ["Gap record", "what planning could not bind, counted over runs", "planner, for RSI"],
                ["Plan step", "what each node requires, and its typed ports", "planner, for the run"],
                ["Composition report", "a co-loaded set, what a screener found, confirmed or not", "screening tool, for the planner"],
            ], [2.6, 5.8, 3.8]) | {"size": 13},
            say("0:40", "Eight records sit outside the manifest. Each has one writer and named readers. That is the "
                        "whole data model, and a field no reader uses is removed.",
                ["The run pin is what makes claims traceable and revocation exact"]),
            thus="eight records, one writer each, and every field has a reader"),
    content("b · Architecture", "Two levels: every capsule is tested, some are certified", "gates", "SCHEMA.md A1 to A3",
            figure("figures/lifecycle.png"),
            say("0:40", "Nothing enters untested. Provisional means it loads, stays within its declared effects and "
                        "passes a postcondition, and only steps that check downstream may use it. Certified means every "
                        "output is tested by someone who never saw the code, with an audited judge. A new revision "
                        "goes live only if it improves on what it replaces.",
                ["Today's AI4Research freeze admits only stable capsules, so provisional admission is new work",
                 "Removing the improvement gate cost 8 points in When Self-Evolution Backfires, one run"]),
            thus="nothing enters untested, and certification decides how far an output may travel"),
    content("b · Architecture", "Predicate parity: one predicate, three evaluators", "binding",
            "SCHEMA.md Predicate parity. Don't Offer What Can't Be Done, Contract2Tool",
            figure("figures/parity.png"),
            say("0:50", "This comes from Don't Offer What Can't Be Done. The gate evaluates each skill's own exit "
                        "conditions, so a blocked skill could not have completed. That holds only while the gate and "
                        "the skill agree, which the authors call predicate parity. Here a precondition is declared once. "
                        "The filter and dispatch run the same evaluator on it, and certification tests the capsule's own "
                        "exit logic against it at the boundary, with missing state and with stale state.",
                ["Each precondition says when its state is readable: at planning, like a credential, or only at dispatch",
                 "Contract2Tool: a keyword top-5 filter lowered success from 0.775 to 0.620, contract filtering raised it to 0.980",
                 "Today AI4Research's filter never reads preconditions, and dispatch checks four fixed kinds: two predicate sets",
                 "Parity is a release invariant: any change to exit logic is a new revision and repeats the tests",
                 "Contract2Tool: synthetic 100-tool registry, 102 tasks, mocked execution"]),
            thus="one declared predicate, so the filter and the capsule cannot silently disagree",
            ),
    content("b · Architecture", "Parity rules, and the paper's three failure modes", "binding",
            "SCHEMA.md Predicate parity. Don't Offer What Can't Be Done p3, p5-6",
            {"kind": "lines", "size": 15, "items": [
                "1  A precondition is data over declared state. Intent never is",
                "2  The filter and dispatch run one evaluator over one declaration",
                "3  Only preconditions readable at planning enter the filter, after their parity test",
                "4  Certification tests the body at the boundary, with state missing and stale",
                "5  Any change to exit logic is a new revision and repeats the tests",
                "6  Unreadable state blocks by default, and passing needs a stated reason",
                "7  A body reports which precondition stopped it",
                "8  Passing a precondition grants no right to any effect",
            ]},
            say("0:45", "Eight rules keep parity. A precondition is data, never intent. The filter and dispatch run one "
                        "evaluator. Only preconditions readable at planning enter the filter, and only after their parity test "
                        "passes. Certification tests the body at the boundary, with missing and with stale state. Any "
                        "change is a new revision that repeats the tests. The unavailable-state policy is explicit, block "
                        "by default. A body reports which precondition stopped it. And passing a precondition grants no right to any "
                        "effect. Each failure mode the paper names "
                        "then leaves a record.",
                ["Predicate drift shows as an exit on a precondition dispatch passed, then revalidation",
                 "State staleness shows as the filter passing and dispatch blocking. Backend drift as a violated contract"]),
            thus="each way the filter and the capsule can drift apart leaves a record"),
    content("b · Architecture", "Existing tools, skills, MCP and A2A enter as provisional", "binding", "SCHEMA.md A6",
            table([
                ["Source", "Derived automatically", "Written to certify"],
                ["agent-core ToolCard", "name, description, inputs, its flags", "outputs, postconditions"],
                ["MCP server", "each tool's name, description, schemas, effect proposals", "postconditions"],
                ["SKILL.md skill", "name, description, a hash per file", "inputs, outputs, postconditions"],
                ["A2A agent", "name, description, version, input and output modes", "typed inputs and outputs, postconditions"],
                ["Old AI4Research capsule", "contract, effects, postconditions", "tests from an author who never saw the code"],
            ], [2.8, 5.4, 4.0]),
            say("0:35", "Nothing is rewritten to enter. An importer fills what it can derive and invents nothing. A "
                        "person confirms the effects and writes one postcondition, and the capsule enters as "
                        "provisional. Certification is where the real test work is.",
                ["Inferred effects are the weak part of an imported contract, so a person confirms them",
                 "A remote MCP server or A2A agent is pinned by endpoint and version"]),
            thus="an import is usable the day it arrives, and certified when its tests are written"),
    content("c · Position", "Where the schema is read in an AI4Research run", "external", "SCHEMA.md B4, B6. AI4Research workflow",
            figure("figures/fits-slide.png"),
            say("0:40", "The top row is a sprint: the filter on declared fields, a model binds each step and a second "
                        "reviews the fit, the freeze pins exact hashes, and agent-core runs them while in-run gates judge "
                        "the outputs. The bottom row runs any time: a gap after repair goes to RSI, the verifier checks "
                        "the build, and admission changes only the next run.",
                ["At dispatch each live hash must equal its pin, which is new",
                 "Each claim records the binding that produced it, so revocation taints exactly its claims"])),
    content("c · Position", "Plan steps and dependencies, today and in the schema", "binding",
            "SCHEMA.md B6. AI4Research and Symphony read in source",
            table([
                ["", "Today, AI4Research and Symphony", "In the schema"],
                ["Step inputs", "typed, but unknown matches any same-named input", "exact types from one vocabulary"],
                ["Edges between steps", "step ids, or edges a model proposes at 0.7", "declared ports, output to input"],
                ["Preconditions", "four kinds at dispatch, never in the filter", "one predicate, filter and dispatch"],
                ["Change to a capsule", "rejected at the freeze, then frozen copies run", "kept, plus a hash check at dispatch"],
                ["Unmet requirement", "bounded re-planning, or needs input", "typed outcomes, and a gap record for RSI"],
            ], [3.0, 5.0, 4.2]),
            say("0:35", "Both systems already give plan nodes requirements, so the schema keeps what they do and "
                        "replaces inference with declaration: ports instead of guessed edges, one declared predicate "
                        "at planning and dispatch, and a pin for every dependency.",
                ["AI4Research pins guard capsules at the freeze, but resolves MCP providers live",
                 "A failed step still blocks its descendants, which reopen on recovery"]),
            thus="it keeps what works today, and replaces inference with declaration"),
    content("c · Position", "How the schema plugs into agent-core and Symphony", "dispatch",
            "agent-core e23806c1 with Symphony, read in source",
            [figure("figures/integration.png")],
            say("0:45", "The capsule layer is new and sits beside Symphony on agent-core. Its provider feeds Symphony's "
                        "fingerprints and graph through CapabilityProvider, for skills, subagents and agents. Each "
                        "availability change calls SkillGraphUpdater. The capsule layer checks the hash and agent-core's "
                        "binder loads from the store, its rail gives tool-call spans for declared effects, and a new rail "
                        "saves the run pins. Each hook exists today, and the next slide lists what each still needs.",
                ["Symphony's graph takes only skills, subagents and agents. Tool, MCP and A2A capsules go through the filter and binder",
                 "AI4Research binds typed steps, so the filter runs per step. Symphony plans in one call, so it filters per query",
                 "Declared ports replace edges a model proposes at 0.7 confidence",
                 "Effect-level observation is the one likely agent-core change"]),
            thus="it plugs into interfaces that exist, and the capsule layer is the new code"),
    content("c · Position", "The hooks exist, and what each still needs", "dispatch", "agent-core e23806c1, read in source",
            table([
                ["Schema part", "Existing hook", "Gap the capsule layer fills"],
                ["What planning may see", "CapabilityProvider, atomic", "the graph takes only skills, subagents, agents"],
                ["Availability changes", "SkillGraphUpdater", "one revision per id, and each change calls a model"],
                ["Manifest model", "CapabilityIO, ToolCard", "a manifest reusing CapabilityIO"],
                ["Loading", "apply_extension_hot", "no hash check, so load from the immutable store"],
                ["Observed effects", "before_tool_call rail", "a tool capsule's internals stay invisible"],
                ["Run pin", "LoadRecord, TrajectoryStore", "records live in memory, so a new rail saves pins"],
                ["Unmet input", "needs_input", "kept, beside the typed unmet outcomes"],
            ], [3.0, 4.0, 5.2]) | {"size": 13},
            say("0:45", "Every connection starts from an interface agent-core already has, and each has a gap I checked in "
                        "source. The graph only takes skills, subagents and agents. It keeps one revision per id and calls "
                        "a model on every change. The binder has no hash check, so loading goes through the immutable store. "
                        "Load records live in memory, so a new rail saves the run pin.",
                ["File and line for each hook are in the companion's hooks table and asks/symphony-agent-core.md"]),
            thus="the interfaces exist, and the capsule layer's own code fills each gap"),
    content("d · Dependencies", "What the schema needs from the system and each teammate", "external", "SCHEMA.md Part B, asks/",
            figure("figures/deps.png"),
            say("0:35", "Each dependency is a record both sides agree on, and none says how the other side works. "
                        "Verification works at three levels: the capability at admission, the system at each sprint, and "
                        "the verifier itself through its audit.",
                ["RSI and verification have four months, so their two formats are settled first",
                 "skillhub, ScienceDiscovery and jiuwenswarm are import sources and patterns, and need no change"]),
            thus="each dependency is a record both sides agree on"),
    content("d · Dependencies", "If a dependency is not there yet", "external", "SCHEMA.md A2, A4, B4",
            table([
                ["Missing", "What happens meanwhile"],
                ["Candidate packages from RSI", "capsules come only from the importer, as provisional"],
                ["A verifier audit", "judged verdicts are advisory, only deterministic and reference checks count"],
                ["Effect-level observation", "code-heavy capsules stay provisional, tool-only capsules can certify"],
                ["A model outside the candidates", "only steps accepting provisional capsules may run it, then revalidation"],
                ["A vocabulary owner", "the capsule layer seeds it from Symphony's"],
            ], [4.2, 8.0]),
            say("0:35", "Each missing piece lowers what can be certified, never what is checked. So the first milestone "
                        "needs nothing outside this team."),
            thus="each gap lowers what is certified, never what is checked"),
    content("e · Similar designs", "Others watch a capability, this schema declares it", "external",
            "Papers read in full. openJiuwen read in source. Public specifications",
            table([
                ["System", "Reference for correct", "Kind"],
                ["Alita-G, Darwin Godel Machine", "the task outcome", "observed"],
                ["Symphony's fingerprint", "quality gathered from use", "observed"],
                ["Skill Drift, Contract2Tool", "contracts inferred from documents and traces", "inferred"],
                ["skillhub, ScienceDiscovery", "a person or a policy", "reviewed"],
                ["Don't Offer What Can't Be Done", "each skill's own exit conditions", "declared, selection only"],
                ["MCP, SKILL.md, A2A cards", "a name and a schema, unchecked", "declared, unchecked"],
                ["GraSP, Agent Behavioral Contracts", "preconditions and effects, checked in the run", "declared, not tied to admission"],
                ["This schema", "the author's declaration, tested before use", "declared and tested"],
            ], [4.2, 5.2, 2.8]) | {"size": 13},
            say("0:35", "Every system checks something. The difference is where the reference for correct comes from. "
                        "Here it is the author's declaration, tested before anything is kept and used again at "
                        "selection and dispatch.",
                ["RelAIBuild checks file scope after an edit lands, detection rather than prevention",
                 "Lockfiles and Sigstore prove who built something, not what it does"]),
            thus="declared contracts exist, but none is tied to admission and selection"),
    content("f · Advantages", "Five advantages, each with what would prove it wrong", "claims", "SCHEMA.md, PAPER-LEDGER.md",
            table([
                ["Advantage", "Proved wrong if"],
                ["safer selection: what cannot run is never offered", "a capsule passes the filter, then exits on that precondition, or a false block"],
                ["fewer tokens at selection", "no drop in selection tokens against today's filter, at equal success"],
                ["a kept capability's own job is tested", "a certified capsule fails a held-out test of its declared job"],
                ["a lenient verifier becomes visible", "retirements stop while evictions continue, and no audit follows"],
                ["claims trace to exact capsules, imports need no rewrite", "a claim has no binding and hash, or an import needs code changes"],
            ], [5.6, 6.6]),
            say("0:35", "Each advantage comes with what would disprove it, so the room can hold the design to it.",
                ["Not claimed: fixing degradation at scale, identical replays, safe combinations, or task success",
                 "Much of the degradation at scale is agents using no skill at all, which a filter cannot fix"]),
            thus="each advantage names the result that would disprove it"),
    content("f · Advantages", "Code removes what cannot run before a model chooses", "binding",
            "Don't Offer What Can't Be Done. Contract2Tool. AI4Research planner read in source",
            [figure("figures/funnel.png")],
            say("0:45", "Every capsule the filter removes is one no model can pick. That is safer, because the model "
                        "cannot pick what cannot run, and cheaper, because its full description shrinks to one line. "
                        "In AI4Research the binding model receives every eligible candidate's full catalog row, and again "
                        "on repair, so the saving carries over. How much is measured in M2, not assumed.",
                ["Don't Offer: 59.1% fewer description tokens after matching, 90.5% combined. Not billed cost or latency",
                 "Contract2Tool: 26,172 to 2,528 tokens a task, success 0.775 to 0.980",
                 "More Skills, Worse Agents: pass rate 0.49 with the right skills alone, 0.28 at 202 skills"]),
            thus="safer and cheaper: never offered, and one line instead of a full row"),
    content("f · Advantages", "Tokens: what the papers measured, and what carries over", "binding",
            "Don't Offer What Can't Be Done, Contract2Tool, SkillFuzz. AI4Research and Symphony read in source",
            table([
                ["Source", "Measured", "Carries over because"],
                ["Don't Offer What Can't Be Done", "59.1% fewer description tokens after matching, 90.5% combined", "a removed capsule is never offered"],
                ["Contract2Tool", "26,172 to 2,528 tokens a task, success 0.775 to 0.980", "the filter reads declared contracts"],
                ["AI4Research today", "full rows for eligible capsules, short exclusion rows for the rest", "a precondition turns a full row into a short one"],
                ["Symphony today", "the planner reads names and descriptions, checks I/O after the plan", "the filter moves checks before it"],
            ], [3.4, 5.0, 3.8]),
            say("0:45", "The papers measured the size of the effect. AI4Research's planner shows the mechanism applies, "
                        "because the binding model reads every eligible capsule's full catalog row, and again on repair. "
                        "I do not claim a number for AI4Research. The run pin records what was offered and blocked and "
                        "the selection tokens, so M2 measures it against today's filter.",
                ["Baseline is today's filter, which already removes on types and effects. 46 capsules today, so the share grows with the library",
                 "M2 reports false blocks and task success beside tokens, since over-blocking also lowers tokens",
                 "Don't Offer: ten skills, one month, description tokens, not billed cost or latency",
                 "Contract2Tool: synthetic registry and mocked execution. A keyword filter lowered success to 0.620"]),
            thus="the mechanism carries over, and M2 measures the size here"),
    content("f · Advantages", "What the schema does not claim", "claims", "companion.md, PAPER-LEDGER.md",
            {"kind": "lines", "size": 19, "items": [
                "Fixing degradation at scale: much of it is agents using no skill, which a filter cannot fix",
                "Identical replays: a model behind an API changes, so runs are recoverable, not identical",
                "Safe combinations: drift rose from 4.7% to 66.5% of plans, so combinations are screened, not certified",
                "Task success: passing the filter means no declared exit holds, not that the capsule succeeds",
            ]},
            say("0:30", "Four limits, so the design is held to what it offers and no more. Each gate judges one capsule "
                        "at a time, and composition risk is real."),
            thus="held to what it offers, and no more"),
    content("g · Feasibility", "Every part exists somewhere, the work is combining them", "build",
            "SCHEMA.md. Each paper read in full",
            [table([
                ["Part", "In openJiuwen or AI4Research", "Built in a paper"],
                ["Store, pinning, loading", "ScienceDiscovery store, agent-core binder", "Execution lineage"],
                ["Filter, binding, fit review", "AI4Research's planner", "Don't Offer What Can't Be Done"],
                ["Held-out tests, separate verifier", "program_opt, skillhub review", "Beyond Task Completion, CoEvoSkills"],
                ["Verifier audit, typed verdicts", "not yet", "The Blind Curator, Cognitive Admission Control"],
                ["Retirement under a cap, drift", "not yet", "Library Drift, Skill Drift"],
            ], [3.6, 4.4, 4.2])],
            say("0:45", "Each part has been built somewhere and no one has combined them. The schema is easy to write "
                        "and hard to prove, so the risk is the combination. M1 is the store, importer and provisional "
                        "admission. M2 puts declared predicates in the filter and measures blocked picks and selection "
                        "tokens. The test is a four-arm comparison on AI4Research tasks.",
                ["Risks: effects seen only at tool-call level, provisional admission changes the freeze, ports change Symphony's graph",
                 "Cost: more work per capability, some latency, some rejections a person would accept",
                 "Prediction: fewer kept capsules fail their own job, fewer unrunnable ones are offered, fewer selection tokens"]),
            thus="who owns each part is for the room to decide, since the capsule touches every team"),
    content("g · Feasibility", "Five milestones, provisional first", "build", "SCHEMA.md, companion.md",
            [figure("figures/milestones.png") | {"h": 1.7},
             table([
                ["", "Needs", "Measured by"],
                ["M1 store, importer, provisional admission", "nothing outside this team", "imports admitted, run pins complete"],
                ["M2 declared filter, after parity tests", "M1", "blocked picks, false blocks, tokens, success"],
                ["M3 certification, verifier audit", "a verdict format, a sandbox", "held-out failures of certified capsules"],
                ["M4 availability, librarian", "the candidate package format", "retirements by reason"],
                ["M5 agents as composites", "M4", "composites admitted with pinned children"],
             ], [4.6, 3.8, 3.8]) | {"size": 13}],
            say("0:40", "Each milestone is usable on its own. M1 needs nothing outside this team. M2 is where the token and "
                        "safety claims get measured. M5, agents as composites, comes last.",
                ["M5: agents as composites, first a gate, after M4"]),
            thus="an order to discuss, not a division of work yet"),
    content("Workshop", "Questions for the room, each with a default", "external", "SCHEMA.md, asks/",
            table([
                ["Question", "Default"],
                ["Who owns the model that binds capsules?", "Symphony's planner, fed by the provider, filter first"],
                ["Fail open or closed when state is unreadable?", "closed, stated per precondition"],
                ["What false-pass ceiling counts toward certification?", "0.05 until measured"],
                ["Who owns the observing sandbox?", "the capsule layer, on agent-core's tool-call hooks"],
                ["What does a sprint-level failure send?", "the run and step, traced through the run pin"],
                ["What counts as a different author for tests?", "a separate session with no access to the code"],
            ], [6.4, 5.8]),
            say("0:35", "These are the decisions that belong with other components. Each has a default, so none of "
                        "them blocks the first milestone.",
                ["Also open: the type vocabulary, how model candidates are expressed, the librarian, Ground Truth"]),
            thus="each answer changes a record, not the idea"),
    backup("Eight invariants hold whatever the specification becomes", "freeze", "SCHEMA.md",
           {"kind": "lines", "size": 17, "items": [
               "1  The contract is the only interface",
               "2  The library is append-only. A better version is a new revision",
               "3  A run sees only the versions it started with",
               "4  Whatever decides never builds, and nothing may change the gate or the verifier",
               "5  A capsule is certified only on tests from an author who never saw its code",
               "6  Every write, execute and network effect says how it is undone, or that it cannot be",
               "7  Admission has a threshold, and this team owns it",
               "8  Eligibility is decided only by declared predicates, through one evaluator",
           ]}),
    backup("Every manifest field, and its reason", "library", "SCHEMA.md A1",
           table([
               ["Field", "Why"],
               ["identity, revision, version", "a stable id, and a new revision for every change"],
               ["description, binding", "what the binding model reads, and how agent-core loads it"],
               ["inputs, outputs, effects", "exact types, and every effect with how it is undone"],
               ["preconditions, postconditions", "one declared predicate, and tests of the capsule's own job"],
               ["dependencies, components", "every dependency pinned, a hash per file"],
               ["load_mode, lineage", "loaded into context or invoked, and what it replaces"],
               ["budget, children", "for agents: limits between calls, and the exact capsules inside"],
           ], [4.2, 8.0])),
    backup("Strict by default, flexible by declaration", "library", "SCHEMA.md A5, after v1",
           table([
               ["Dependency declared as", "What follows"],
               ["no role", "pinned by hash, model version, service version or capsule hash"],
               ["floating, with a role and contracts", "may move. The capsule stays provisional, and each contract is checked"],
               ["contract violated", "a repair request naming the broken assumption"],
           ], [4.4, 7.8])),
    backup("What the schema gives the librarian", "library", "SCHEMA.md B5",
           table([
               ["Job", "What the schema gives"],
               ["Admit", "a verdict per check, and what a deferral is waiting for"],
               ["Keep the active set small", "revisions activate only on improvement, evictions record the value lost"],
               ["Retire", "trials, threshold and contribution, tied to the verifier's audit"],
               ["Watch the verifier", "quality retirements against cap evictions trigger an audit"],
               ["Watch parity", "block rates per precondition, gate against exit disagreements"],
               ["Revoke, re-check, fill gaps", "exact taint down to claims, certificate expiry, unanswered gaps"],
           ], [4.2, 8.0])),
    backup("agent-core fully provides one of five needed properties", "dispatch", "agent-core e23806c1, read in source",
           table([
               ["", "Needed", "What agent-core has"],
               ["H1", "reversible registration", "yes: hot apply and unapply, undone in reverse order"],
               ["H2", "dependency tracking", "no. The capsule layer closes capsule dependencies at bind"],
               ["H3", "immutable versioned artifacts", "for graph artifacts only"],
               ["H4", "a reconstructable execution log", "an append-only trajectory archive, once wired"],
               ["H5", "a record of what ran", "tool calls only, not what code does inside"],
           ], [0.9, 4.6, 6.7])),
    backup("openJiuwen schemas each hold part of this one", "external", "Read in source, 2026-09-21",
           table([
               ["Schema", "Has", "Lacks"],
               ["agent-core ToolCard", "identity, inputs, exposure, parallel-safe, stateless, idempotent", "outputs, postconditions, hashes, versions"],
               ["Symphony descriptor", "typed inputs and outputs, content hash, available", "preconditions, effects, admission"],
               ["skillhub review", "a review per version, a policy version, a zip hash", "a contract. A version can be force-overwritten"],
               ["ScienceDiscovery library", "per-file hashes, revisions, skills pinned per run", "postconditions, effects, an audited verifier"],
           ], [3.4, 4.6, 4.2])),
    backup("Admission checks, each run by a tool", "gates", "SCHEMA.md A1, A2",
           table([
               ["Check", "Level"],
               ["Manifest valid, file hashes match, binding loads", "both"],
               ["Smoke run within declared effects, at tool-call level", "both"],
               ["At least one postcondition passes on new inputs", "provisional"],
               ["Every output covered, tests from an author who never saw the code", "certified"],
               ["Precondition parity: boundary, missing and stale state", "certified"],
               ["Model judgment", "counts only under the false-pass ceiling"],
               ["An unknown verdict", "defers with a typed evidence request"],
           ], [8.2, 4.0])),
    backup("The supervisor's components, mapped onto the schema", "library", "Supervisor's slides, 2026-09-18",
           table([
               ["Supervisor's component", "Where it lives here"],
               ["Rules, Boundary, Interfaces", "preconditions, effects, typed inputs and outputs"],
               ["Skills", "the body"],
               ["Governance", "lineage, certificates, availability events"],
               ["Eval", "the certificate references the tests, and the gate stays outside"],
               ["Assets, Data", "declared as dependencies, not carried inside"],
               ["Ground Truth", "proposed: reference answers pinned as data, curated by verification"],
           ], [4.2, 8.0])),
    content("Backup", "Risks, each with its answer", "build", "companion.md",
            table([
                ["Risk", "Answer"],
                ["Effects seen only at tool-call level", "code-heavy capsules stay provisional until a sandbox observes effects"],
                ["Provisional admission changes the freeze", "provisional capsules bind only to steps that accept them"],
                ["Declared ports change Symphony's graph", "ports sit beside proposed edges until M2 shows no loss"],
                ["Parity needs exits to report their id", "until tested, a precondition is checked at dispatch only"],
                ["Declarations gamed or under-declared", "another author's suite, reasons for empty lists, observed effects"],
                ["Over-blocking starves steps", "M2 reports false blocks and task success beside tokens"],
            ], [4.8, 7.4]),
            say("0:35", "Six risks, each contained by a design answer. The cost is more work per capability, some latency, "
                        "and some rejections a person would accept."),
            thus="each risk has a contained answer", insert=True),
    content("Backup", "The test that decides whether the combination works", "build", "companion.md",
            table([
                ["Arm", "Library", "Prediction"],
                ["1", "no library", "the baseline"],
                ["2", "built without admission", "more kept capsules fail their job, more unrunnable ones offered"],
                ["3", "curated by observation, a judge retires by outcome", "the comparison the design must beat"],
                ["4", "the same library under this schema", "fewer failures and unrunnable offers, success no lower than 3"],
            ], [1.0, 4.4, 6.8]),
            say("0:35", "Each paper shows a part works in its own setting, not that the whole works here. Only this "
                        "comparison on AI4Research's own tasks, with the same models and budget, can show that.",
                ["Ground Truth reference answers curated by verification, pinned as data",
                 "An ablation with the filter alone separates what admission adds from what the filter adds"]),
            thus="only a comparison on AI4Research's own tasks proves the combination", insert=True),

]

spec = {"meta": {"id": "capsule-workshop", "title": "Capability Capsule", "inserts": "shown",
                 "budget": {"target": "20:00", "max": "25:00"}, "words_per_second": 2.3},
        "slides": slides}
out = Path(__file__).with_name("deck.json")
out.write_bytes(json.dumps(spec, ensure_ascii=False, indent=1).encode("utf-8"))
print("wrote", out, len(slides), "slides")
