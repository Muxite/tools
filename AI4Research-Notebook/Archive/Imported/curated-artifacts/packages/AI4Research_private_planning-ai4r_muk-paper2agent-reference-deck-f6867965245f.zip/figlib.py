"""Drawing helpers for the workload-profiling and Paper2Agent decks.

Colour = stage (palette_local.STAGE). Filled tints are used on purpose here: the decks are read in a room and
colour carries which part of the system a box belongs to. Every box also carries a text label.
Canvas units: x runs 0..100, y runs 0..100*aspect. Font sizes are real points at slide size (the figure is
saved at the inch width it is shown at).
"""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon  # noqa: E402

from palette_local import GREY, INK, STAGE, tint  # noqa: E402

plt.rcParams.update({"font.family": "DejaVu Sans", "savefig.dpi": 220})

EXT = "#6b6b6b"
BAD = "#D55E00"
GOOD = "#008A63"


def col(name):
    return {"failed": BAD, "good": GOOD}.get(name) or STAGE.get(name, name)


def box(ax, x, y, w, h, title, sub="", color="dispatch", fs=13, fill=0.22, solid=False, subfs=None,
        tcolor=INK, lw=1.8, dashed=False, rounding=0.8):
    c = col(color)
    fc = c if solid else (tint(c, fill) if fill is not None else "white")
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={rounding}", facecolor=fc,
                                edgecolor=c, linewidth=lw, zorder=2, linestyle=(0, (4, 2)) if dashed else "-"))
    tc = "white" if solid else tcolor
    if sub:
        ax.text(x + w / 2, y + h * 0.66, title, ha="center", va="center", fontsize=fs, fontweight="bold",
                color=tc, zorder=4, linespacing=1.1)
        ax.text(x + w / 2, y + h * 0.30, sub, ha="center", va="center", fontsize=subfs or fs * 0.78,
                color="white" if solid else GREY, zorder=4, linespacing=1.15)
    else:
        ax.text(x + w / 2, y + h / 2, title, ha="center", va="center", fontsize=fs, fontweight="bold", color=tc,
                zorder=4, linespacing=1.1)


def doc(ax, x, y, w, h, title, sub="", color="intent", fs=13, fill=0.22, subfs=None):
    c = col(color)
    f = min(2.0, w * 0.12, h * 0.3)
    pts = [(x, y), (x + w, y), (x + w, y + h - f), (x + w - f, y + h), (x, y + h)]
    ax.add_patch(Polygon(pts, closed=True, facecolor=tint(c, fill), edgecolor=c, linewidth=1.8, zorder=2))
    ax.plot([x + w - f, x + w - f, x + w], [y + h, y + h - f, y + h - f], color=c, lw=1.4, zorder=3)
    if sub:
        ax.text(x + w / 2, y + h * 0.68, title, ha="center", va="center", fontsize=fs, fontweight="bold",
                color=INK, zorder=4, linespacing=1.1)
        ax.text(x + w / 2, y + h * 0.32, sub, ha="center", va="center", fontsize=subfs or fs * 0.78,
                color=GREY, zorder=4, linespacing=1.15)
    else:
        ax.text(x + w / 2, y + h / 2, title, ha="center", va="center", fontsize=fs, fontweight="bold",
                color=INK, zorder=4)


def chip(ax, x, y, text, color="dispatch", fs=10.5, solid=True, ha="center"):
    c = col(color)
    ax.text(x, y, text, ha=ha, va="center", fontsize=fs, fontweight="bold", color="white" if solid else c,
            zorder=6, bbox=dict(boxstyle="round,pad=0.3", fc=c if solid else "white", ec=c, lw=1.2))


def arrow(ax, p1, p2, color=INK, lw=2.0, dashed=False, rad=0.0, ms=20, style="-|>"):
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle=style, mutation_scale=ms, color=color, lw=lw, shrinkA=0,
                                 shrinkB=0, zorder=1, connectionstyle=f"arc3,rad={rad}",
                                 linestyle=(0, (4, 2.5)) if dashed else "-"))


def elbow(ax, pts, color=INK, lw=2.0, dashed=False, ms=20):
    xs, ys = zip(*pts[:-1])
    ax.plot(list(xs), list(ys), color=color, lw=lw, zorder=1, linestyle=(0, (4, 2.5)) if dashed else "-",
            solid_capstyle="butt")
    arrow(ax, pts[-2], pts[-1], color=color, lw=lw, dashed=dashed, ms=ms)


def text(ax, x, y, s, fs=12, color=INK, ha="center", va="center", bold=False, italic=False, bg=False, ls=1.15):
    ax.text(x, y, s, ha=ha, va=va, fontsize=fs, color=color, fontweight="bold" if bold else "normal",
            style="italic" if italic else "normal", zorder=6, linespacing=ls,
            bbox=dict(boxstyle="square,pad=0.15", fc="white", ec="none") if bg else None)


def heading(ax, x, y, s, color="intent", fs=12.5, ha="left"):
    ax.text(x, y, s.upper(), ha=ha, va="center", fontsize=fs, fontweight="bold", color=col(color), zorder=6)


def band(ax, x, y, w, h, color="intent", alpha=0.07):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.0", facecolor=col(color),
                                edgecolor="none", alpha=alpha, zorder=0))


FS = 1.0


def canvas(width_in, aspect, draw, path, fs=None):
    fig = plt.figure(figsize=(width_in, width_in * aspect))
    ax = fig.add_axes([0, 0, 1, 1])
    k = FS if fs is None else fs
    _text = ax.text

    def scaled(*a, **kw):
        if "fontsize" in kw:
            kw["fontsize"] = kw["fontsize"] * k
        return _text(*a, **kw)
    ax.text = scaled
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100 * aspect)
    ax.axis("off")
    draw(ax)
    fig.savefig(path, facecolor="white")
    plt.close(fig)
