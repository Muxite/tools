"""Writes deck.json for the Paper2Agent deck (under 15 minutes). Build with:
    python figs2.py && python build_spec2.py
    tundlekit deck lint deck.json && tundlekit deck build deck.json -o "Paper2Agent and AI4Research.pptx"
Sources: paper2agent-reference/00-core-value-and-original-requirement.md and 06-paper2agent-cc-container-proposal.md
(Paper2Agent commit 8c2d059, static inspection only, nothing was executed), arXiv 2509.06917, Anthropic MCP donation post.
"""
import json
import pathlib

HERE = pathlib.Path(__file__).parent
FIG = "figures/"
REF = "paper2agent-reference/00-core-value-and-original-requirement.md"
P06 = "paper2agent-reference/06-paper2agent-cc-container-proposal.md"


def notes(time, main, supp=None):
    say = "Main points:\n" + "\n".join("- " + m for m in main)
    if supp:
        say += "\nSupplemental points:\n" + "\n".join("- " + s for s in supp)
    return {"time": time, "say": say}


S = []

S.append({"type": "title", "title": "Paper2Agent for AI4Research",
          "subtitle": "Is it worth a closer look, as a capsule builder in front of admission, the library and the planner?",
          "byline": "Decision briefing, under 15 minutes",
          "notes": notes("0:15", ["One question: should we look into Paper2Agent further, yes or no",
                                  "Answer first, then the evidence"])})

S.append({"type": "content", "eyebrow": "Verdict", "stage": "gates",
          "title": "Yes to a short spike, no as the self-improvement loop",
          "source": REF + "; " + P06 + " (Paper2Agent commit 8c2d059, static inspection only)",
          "body": {"kind": "table", "rows": [
              ["Question", "Answer", "Why"],
              ["Valuable to AI4Research?", "Yes", "Turns papers with code into tested, source-backed tools we can admit as capsules"],
              ["Does it deliver the 16 Oct request?", "No", "Covers 1 step fully and 1 partly of the 6-step loop. Value judgment, design and before and after tests are ours"],
              ["Can it be a capability capsule?", "Its outputs, yes", "The builder stays an offline job: nothing that decides is a capsule"],
              ["Does it fit admission, library, planner?", "Yes, one adapter", "Candidate capsule enters the existing M1 path. Planner sees only admitted versions"],
              ["What does finding out cost?", "3 to 5 days", "One repo, one host. Narrow full path is 20 to 35 days (provisional)"]],
           "widths": [3.7, 2.2, 6.6], "size": 20},
          "notes": notes("1:15", [
              "Recommendation: spend a 3 to 5 day spike, do not adopt it as the whole feature",
              "Its value is the paper-to-tested-tool conversion, which is real effort saved",
              "The requested loop is judging value, designing, building, and proving improvement",
              "Everything else on the slide follows from that split"],
              ["Final verdict is the team's, this is the recommendation"])})

S.append({"type": "content", "eyebrow": "The original ask", "stage": "intent",
          "title": "It covers one loop step fully and one partly",
          "source": REF + ": Stellven's request of 16 Oct 2026 as supplied; Paper2Agent skills at commit 8c2d059",
          "body": [{"kind": "figure", "path": FIG + "g1_loop.png", "x": 0.4, "y": 1.35, "w": 12.5, "h": 5.0},
                   {"kind": "point", "text": "The ask: a paper goes in, AI4R judges it, designs the feature, builds it and gets stronger",
                    "x": 0.4, "y": 6.45, "w": 12.5, "size": 22}],
          "notes": notes("1:15", [
              "Paper2Agent reads a paper into a reviewed package and wraps existing repo code as tested tools",
              "It does not judge value to AI4R, write our PRD, or compare to our baseline",
              "A paper with no usable repo needs another implementation path"],
              ["The paper-to-skill route gives a reading package, not an executable capability"])})

S.append({"type": "content", "eyebrow": "What it is", "stage": "dispatch",
          "title": "It turns a paper and its repo into tested MCP tools",
          "source": "arXiv 2509.06917 (Paper2Agent, v2 Oct 2025); repo skills: paper2mcp/SKILL.md and references/output-delivery.md",
          "body": {"kind": "figure", "path": FIG + "g3_how.png"},
          "notes": notes("1:00", [
              "Multiple agents analyze the paper and codebase, build an MCP server, then generate and run tests to harden it",
              "Orchestration is instructions for a host agent system, not a ready scheduler we can embed",
              "The paper reports case studies but no accuracy numbers in the abstract"],
              ["Runtime ZIP is delivered, evidence is kept outside it, so we must capture both"])})

S.append({"type": "content", "eyebrow": "Integration", "stage": "library",
          "title": "Plug it in as an offline builder in front of admission",
          "source": P06 + ", lifecycle; design-package/reference/run-plan.md; capability-capsules/library-and-checking.md",
          "body": {"kind": "figure", "path": FIG + "g2_fit.png"},
          "notes": notes("1:00", [
              "Builder output becomes a candidate capsule through one new packaging adapter",
              "Independent qualification and protected admission stay exactly as designed for M1",
              "The planner only sees admitted versions in the library snapshot",
              "A failed run never rebuilds a capsule, frozen plans keep their pins"],
              ["Hidden evaluation cases stay outside the builder and the runtime image"])})

S.append({"type": "content", "eyebrow": "Mapping", "stage": "library",
          "title": "Built tools map onto the declaration, with four gaps",
          "source": P06 + ", section: how the existing M1 CC can represent the result",
          "body": {"kind": "table", "rows": [
              ["Declaration part", "Paper2Agent gives", "What we must add"],
              ["ports", "MCP tool input and output schemas", "Scientific units and applicability, JSON shape is not enough"],
              ["needs, changes", "Dataset and model pins, output files", "Runtime needs from build deps. Block path parameters and hidden effects"],
              ["guarantees", "Tests against upstream reference results", "Independent held-out cases the builder cannot see"],
              ["lineage", "Build history and evidence", "A linked source and build manifest, lineage object is closed"],
              ["one tool per capsule", "A server with many tools", "Per-tool access limit so one grant is not every tool"]],
           "widths": [2.8, 4.4, 5.3], "size": 20},
          "notes": notes("1:00", [
              "The declaration categories already fit, so the schema does not change for a pilot",
              "The work is the importer, the manifest, and independent evidence",
              "Composite execution is deferred, so dependent operations become separate planned nodes"],
              ["Keep runtime ZIP and evidence bundle together or qualification loses its basis"])})

S.append({"type": "content", "eyebrow": "Decision", "stage": "freeze",
          "title": "Offline builder yes, library capsule no",
          "source": "obby Directives: nothing that decides is a capsule; " + P06 + "; Anthropic, Donating MCP to the Agentic AI Foundation (Dec 2025)",
          "body": [{"kind": "table", "rows": [
              ["Option", "Verdict", "Reason"],
              ["Offline builder feeding admission", "Recommended", "Reuses M1 gates, no hot-path change"],
              ["Paper2Agent itself as a library capsule", "No", "Its orchestration decides and sequences, control stays in protected code"],
              ["Part of the planner", "No", "Planner only picks admitted versions from the snapshot"],
              ["Its generated tools as capsules", "Yes", "One capsule per operation, pinned, admitted on held-out cases"]],
           "widths": [4.6, 2.2, 5.7], "size": 23, "x": 0.4, "y": 1.5, "w": 12.5, "h": 3.6},
                   {"kind": "point", "text": "Industry check: MCP is now the shared tool interface. ChatGPT, Gemini and Microsoft Copilot support it, and Anthropic donated it to the Linux Foundation's Agentic AI Foundation in Dec 2025",
                    "x": 0.4, "y": 5.6, "w": 12.5, "size": 22}],
          "notes": notes("1:00", [
              "Choosing MCP-shaped tools follows what the large vendors already adopted, so it carries less risk",
              "The builder is a side system like the RSI workbench, off the hot path"],
              ["Source for adoption is Anthropic's announcement, adopters named there"])})

S.append({"type": "content", "eyebrow": "Cost and ask", "stage": "claims",
          "title": "Approve a 3 to 5 day spike on one repo and one host?",
          "source": P06 + ", scope and effort; 00-core-value: smallest meaningful pilot. Estimates are provisional design figures, not measured",
          "body": [{"kind": "table", "rows": [
              ["Piece", "Provisional effort", "Notes"],
              ["Spike: one repo, one host", "3 to 5 days", "Source reproducibility, candidate mapping, image build, launcher feasibility"],
              ["Narrow paper-to-capsule path", "20 to 35 days + 5 to 10 review", "Plus 10 to 20 if M1 foundations are incomplete"],
              ["Container profile (optional)", "6 to 12 days + 2 to 3 review", "One CPU, Python, stdio pilot"],
              ["Value judgment, design, implement, compare", "Not sized", "The part Stellven asked for, size after the pilot is chosen"]],
           "widths": [4.5, 3.6, 4.4], "size": 20, "x": 0.4, "y": 1.45, "w": 12.5, "h": 3.6},
                   {"kind": "bullets", "items": [
                       "**Pilot:** one paper aimed at a named AI4R gap, plus one irrelevant paper that must be rejected",
                       "**Success:** a go or no-go with evidence, one bounded capsule, better than the current baseline on held-out cases"],
                    "x": 0.4, "y": 5.4, "w": 12.5, "h": 1.8, "size": 21}],
          "notes": notes("1:15", [
              "The spike answers feasibility before we commit to any M2 scope",
              "The estimates cover supporting parts, not the complete self-improvement loop",
              "Ask: approve the spike, and pick the paper and the AI4R gap it targets"],
              ["Risks: papers without repos, dependency conflicts, evidence lost if only the ZIP is imported"])})

S.append({"type": "divider", "title": "Appendix", "subtitle": "Link to workload profiling, sources",
          "notes": notes("0:05", ["Backup material"])})

S.append({"type": "content", "eyebrow": "Appendix", "stage": "dispatch", "insert": True,
          "title": "The container profile is shared with workload profiling",
          "source": P06 + "; resource-aware-planning/gb10-profiling-plan.md",
          "body": {"kind": "table", "rows": [
              ["Piece", "Paper2Agent use", "Profiling use"],
              ["Image digest and platform", "Pins the tested environment", "Keys the profile record"],
              ["Launch profile", "Entrypoint, mounts, limits", "Quiet-window run configuration"],
              ["Evidence bundle", "Qualification of this exact tuple", "Solo profile of this exact tuple"]],
           "widths": [3.6, 4.4, 4.5], "size": 21},
          "notes": notes("0:30", ["One packaging unit serves both: admission evidence and profile evidence"])})

S.append({"type": "content", "eyebrow": "Appendix", "stage": "external", "insert": True,
          "title": "Source map",
          "source": "Accessed October 2026",
          "body": {"kind": "table", "rows": [
              ["Claim", "Source"],
              ["What Paper2Agent builds, case studies, no numeric metrics in the abstract", "arxiv.org/abs/2509.06917"],
              ["Skills, stages, runtime ZIP and separate evidence", "other-repos/Paper2Agent at commit 8c2d059: skills/paper2agent/paper2mcp/"],
              ["Loop, verdict, pilot, effort", "paper2agent-reference/00-core-value-and-original-requirement.md and 06-paper2agent-cc-container-proposal.md"],
              ["MCP adoption and Linux Foundation donation", "anthropic.com/news/donating-the-model-context-protocol-and-establishing-of-the-agentic-ai-foundation"],
              ["Admission, library, planner, binder", "design-package: capability-capsules/library-and-checking.md, reference/run-plan.md"]],
           "widths": [5.4, 7.1], "size": 17},
          "notes": notes("0:10", ["Source list"])})

spec = {"meta": {"id": "paper2agent", "title": "Paper2Agent for AI4Research", "inserts": "shown",
                 "budget": {"target": "12:00", "max": "15:00"}, "words_per_second": 2.3, "theme": "bold"},
        "slides": S}
(HERE / "deck.json").write_text(json.dumps(spec, indent=1, ensure_ascii=False), encoding="utf-8", newline="\n")
print("slides", len(S))
