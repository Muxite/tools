"""Shared colour system for both reports and both decks.

Colour = stage. Style = actor: a model call is a tinted fill with a MODEL tag, deterministic code
is a white fill with a stage-colour border and a CODE tag, a record is drawn as a document.
Outcome colours are used only for node states in the DAG figures. Hues are Okabe-Ito based, so
they stay distinct for colour-blind readers; every figure also keeps text labels, so nothing
depends on colour alone.
"""

INK, GREY, HAIR, PALE = "#000000", "#4d4d4d", "#9a9a9a", "#ececec"

STAGE = {
    "intent": "#0072B2",      # compiled intent, requirement contract
    "binding": "#2A8FA8",     # plan and capsule binding
    "freeze": "#7B3FA0",      # freeze, and anything frozen or protected
    "dispatch": "#D98200",    # dispatch, operator execution
    "gates": "#008A63",       # gates, evaluation
    "claims": "#B8527F",      # claims, delivery
    "build": "#3D4FB0",       # capsule cold path: deciding and building
    "library": "#8C5A2B",     # capsule library, versions, lifecycle
    "external": "#6b6b6b",    # outside the system: papers, MCP servers, peers
}

OUTCOME = {
    "passed": "#008A63",
    "failed": "#D55E00",
    "skipped": "#bdbdbd",
    "running": "#D98200",
    "ready": "#0072B2",
    "pending": "#ffffff",
}

# the same stage colours for python-pptx (no leading #)
PPT = {k: v.lstrip("#").upper() for k, v in STAGE.items()}


def tint(hexcolor, amount=0.18):
    """Mix a colour with white; amount is the share of the colour kept."""
    h = hexcolor.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    mix = [round(255 - (255 - c) * amount) for c in (r, g, b)]
    return "#{:02x}{:02x}{:02x}".format(*mix)
