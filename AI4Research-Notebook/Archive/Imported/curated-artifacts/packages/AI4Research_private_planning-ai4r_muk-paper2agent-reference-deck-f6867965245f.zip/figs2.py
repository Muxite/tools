"""Figures for the Paper2Agent deck. Run: python figs2.py  (writes figures/*.png)"""
import pathlib

from figlib import BAD, EXT, GOOD, arrow, band, box, canvas, chip, col, doc, elbow, heading, text
from palette_local import GREY, INK

HERE = pathlib.Path(__file__).parent
OUT = HERE / "figures"
OUT.mkdir(exist_ok=True)
W = 12.5
A = 0.465


def g1(ax):
    """The requested loop, and how much of it Paper2Agent covers."""
    steps = [
        ("1  Read the\npaper", "YES", "Reviewed reading\npackage with sources", "Nothing extra"),
        ("2  Judge value\nto AI4R", "NO", "Not in its scope", "Score gap, overlap,\nfit, cost, uncertainty"),
        ("3  PRD and\ndesign", "NO", "Not in its scope", "Bounded feature spec\nin our PRD format"),
        ("4  Implement\nthe change", "PARTLY", "Wraps existing repo\ncode as MCP tools", "Papers with no repo,\nplatform changes"),
        ("5  Compare to\nbaseline", "NO", "Tests tools against\nthe repo's own results", "Held-out before and\nafter comparison"),
        ("6  Admit if\nit helps", "NO", "Not in its scope", "Admission and\nlibrary entry"),
    ]
    w = 14.6
    gap = 2.0
    for i, (t, st, gives, adds) in enumerate(steps):
        x = 1.0 + i * (w + gap)
        c = {"YES": GOOD, "PARTLY": "#D98200", "NO": BAD}[st]
        box(ax, x, 30.5, w, 12.5, t, "", "intent", 14, fill=0.2)
        chip(ax, x + w / 2, 27.6, f"PAPER2AGENT: {st}", c, 10.5)
        ax.text(x + 0.3, 21.8, "It gives", ha="left", va="center", fontsize=11, fontweight="bold", color=GREY)
        ax.text(x + 0.3, 17.0, gives, ha="left", va="center", fontsize=11.5, color=INK, linespacing=1.2)
        ax.text(x + 0.3, 10.8, "AI4R adds", ha="left", va="center", fontsize=11, fontweight="bold", color=GREY)
        ax.text(x + 0.3, 5.6, adds, ha="left", va="center", fontsize=11, color=INK, linespacing=1.2,
                fontweight="bold")
        if i < 5:
            arrow(ax, (x + w + 0.1, 36.7), (x + w + gap - 0.1, 36.7), lw=2.4)


def g3(ax):
    """How Paper2Agent builds an MCP server from a paper."""
    heading(ax, 0.5, 44.0, "Paper2MCP route: paper + code to tested tools", "dispatch", 13.5)
    steps = [
        ("Find the\ncode", "paper, repo\ncommit, data", "external"),
        ("Pin the\nenvironment", "exact packages", "library"),
        ("Run the\ntutorials", "reference\nresults", "dispatch"),
        ("Extract\ntools", "parameterized\noperations", "build"),
        ("Test\nthem", "compare to\nreference", "gates"),
        ("Package\nMCP server", "runtime ZIP", "claims"),
    ]
    w = 14.0
    gap = 2.4
    for i, (t, s, c) in enumerate(steps):
        x = 1.0 + i * (w + gap)
        box(ax, x, 26.0, w, 14.0, t, s, c, 14, subfs=11, fill=0.22)
        if i < 5:
            arrow(ax, (x + w + 0.1, 33), (x + w + gap - 0.1, 33), lw=2.4)
    band(ax, 0.3, 3.0, 99.4, 17.0, "claims", 0.07)
    ax.text(1.5, 17.0, "Delivers", ha="left", va="center", fontsize=13, fontweight="bold", color=col("claims"))
    ax.text(1.5, 12.0, "A runtime ZIP with an MCP server. Notebooks, tests, reports and agent records stay outside it.",
            ha="left", va="center", fontsize=12.5, color=INK)
    ax.text(1.5, 7.0, "Paper evidence: three case studies (AlphaGenome, ScanPy, TISSUE), "
            "no accuracy numbers in the abstract.", ha="left", va="center", fontsize=12.5, color=INK)


def g2(ax):
    """Where it joins the AI4R design."""
    band(ax, 0.3, 24.5, 46.5, 20.0, "external", 0.10)
    heading(ax, 1.2, 43.0, "Offline build job, off the hot path", "external", 12.5)
    box(ax, 1.5, 28.0, 13.5, 11.5, "Paper +\nrepo commit", "", "external", 12.5)
    box(ax, 17.5, 28.0, 14.5, 11.5, "Paper2Agent", "wrappers + MCP\nserver, evidence", "external", 12.5, subfs=10)
    box(ax, 34.0, 28.0, 12.0, 11.5, "CC packaging\nadapter", "NEW", "build", 12.0, subfs=10.5)
    arrow(ax, (15.1, 33.7), (17.4, 33.7), lw=2.4)
    arrow(ax, (32.1, 33.7), (33.9, 33.7), lw=2.4)
    band(ax, 49.0, 24.5, 50.7, 20.0, "library", 0.10)
    heading(ax, 50.0, 43.0, "Existing M1 path", "library", 12.5)
    box(ax, 50.0, 28.0, 15.5, 11.5, "Independent\nqualification", "held-out cases", "library", 12.0, subfs=10.5)
    box(ax, 68.0, 28.0, 14.0, 11.5, "Admission", "pins, self-tests", "library", 12.5, subfs=10.5)
    box(ax, 84.5, 28.0, 14.2, 11.5, "Library\nsnapshot", "", "library", 12.5)
    arrow(ax, (46.2, 33.7), (49.9, 33.7), lw=2.4)
    arrow(ax, (65.6, 33.7), (67.9, 33.7), lw=2.4)
    arrow(ax, (82.1, 33.7), (84.4, 33.7), lw=2.4)
    box(ax, 50.0, 7.5, 18.0, 11.5, "Planner", "picks pinned versions", "binding", 12.5, subfs=10.5)
    box(ax, 71.0, 7.5, 12.5, 11.5, "Binder", "freeze", "freeze", 12.5, subfs=10.5)
    box(ax, 86.0, 7.5, 12.7, 11.5, "Runner", "gate", "dispatch", 12.5, subfs=10.5)
    elbow(ax, [(91.5, 27.8), (91.5, 22.5), (59.0, 22.5), (59.0, 19.2)], lw=2.2)
    arrow(ax, (68.1, 13.2), (70.9, 13.2), lw=2.2)
    arrow(ax, (83.6, 13.2), (85.9, 13.2), lw=2.2)
    chip(ax, 22, 14.5, "A failed run never rebuilds a capsule", "failed", 11.5)
    chip(ax, 22, 8.5, "Frozen runs keep their pins", "freeze", 11.5)
    text(ax, 22, 3.0, "Build finishes before a plan freezes", 11.5, GREY, italic=True)


def main():
    canvas(W, 0.465, g1, OUT / "g1_loop.png", fs=1.0)
    canvas(W, 0.465, g3, OUT / "g3_how.png", fs=1.1)
    canvas(W, 0.465, g2, OUT / "g2_fit.png", fs=1.1)
    print("ok")


if __name__ == "__main__":
    main()
